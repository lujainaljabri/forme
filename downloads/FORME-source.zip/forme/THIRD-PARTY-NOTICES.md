FORME uses free and open-source dependencies. The exact versions are recorded
in package-lock.json. Installed package license files remain authoritative.

React and React DOM: MIT, Meta Platforms and contributors.
Vite: MIT, Evan You and contributors.
TypeScript: Apache-2.0, Microsoft.
Dexie: Apache-2.0, David Fahlander.
Recharts: MIT, Recharts contributors.
Lucide: ISC, Lucide contributors (some icon sources derive from Feather, MIT).
Vitest: MIT, Vitest contributors.
Testing Library: MIT, Testing Library contributors.
fake-indexeddb: Apache-2.0, Joshua Bell and contributors.
jsdom: MIT, jsdom contributors.
Inter: SIL Open Font License 1.1, Rasmus Andersson.
Playfair Display: SIL Open Font License 1.1, Claus Eggers Sørensen.

Font license texts are included in public/licenses/ and in the production build.

Supabase JS and its Auth/PostgREST libraries: MIT, Supabase and contributors.
PostgreSQL (local security tests only): PostgreSQL License, PostgreSQL Global Development Group.
