import { readdir, writeFile, mkdir, copyFile } from "node:fs/promises";
async function walk(path) {
  let a = [];
  for (const e of await readdir(path, { withFileTypes: true })) {
    if (e.isDirectory()) a.push(...(await walk(path + "/" + e.name)));
    else a.push(path + "/" + e.name);
  }
  return a;
}
await mkdir("dist/downloads", { recursive: true });
await copyFile(
  "PRIVATE-SHARING.md",
  "dist/downloads/FORME-private-sharing-guide.md",
);
const files = (await walk("dist"))
  .filter((x) => !x.endsWith("sw.js"))
  .map((x) => "./" + x.slice(5));
const version = "forme-" + Date.now();
await writeFile(
  "dist/sw.js",
  `const CACHE=${JSON.stringify(version)};const FILES=${JSON.stringify(files)};self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES)).then(()=>self.skipWaiting()))});self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('forme-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});self.addEventListener('fetch',e=>{if(e.request.method!=='GET'||new URL(e.request.url).origin!==self.location.origin)return;e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).catch(()=>e.request.mode==='navigate'?caches.match('./index.html'):Response.error())))});`,
);
console.log("PWA precache:", files.length, "local assets");
