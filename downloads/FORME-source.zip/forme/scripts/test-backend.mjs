import { spawnSync } from "node:child_process";
import { readFileSync } from "node:fs";
import { randomUUID } from "node:crypto";
const name = "forme-permissions-" + randomUUID().slice(0, 8);
const env = { ...process.env };
for (const key of [
  "DOCKER_HOST",
  "DOCKER_CONTEXT",
  "DOCKER_TLS",
  "DOCKER_TLS_VERIFY",
  "DOCKER_CERT_PATH",
])
  delete env[key];
const docker = ["--host=unix:///var/run/docker.sock"];
function run(args, input) {
  const r = spawnSync("docker", [...docker, ...args], {
    env,
    input,
    encoding: "utf8",
    maxBuffer: 8 * 1024 * 1024,
  });
  if (r.status !== 0) throw Error(r.stderr || r.stdout || String(r.error));
  return r.stdout;
}
try {
  run([
    "run",
    "--name",
    name,
    "--network",
    "none",
    "-e",
    "POSTGRES_PASSWORD=forme-synthetic-local-test-only",
    "-d",
    "postgres:17-alpine",
  ]);
  let ready = false;
  for (let i = 0; i < 60; i++) {
    try {
      run(["exec", name, "pg_isready", "-U", "postgres"]);
      ready = true;
      break;
    } catch {
      await new Promise((r) => setTimeout(r, 500));
    }
  }
  if (!ready) throw Error("Disposable PostgreSQL did not become ready.");
  const input = [
    "backend/test-bootstrap.sql",
    "backend/sharing.sql",
    "backend/permissions.test.sql",
  ]
    .map((p) => readFileSync(p, "utf8"))
    .join("\n");
  const output = run(
    [
      "exec",
      "-i",
      name,
      "psql",
      "-U",
      "postgres",
      "-v",
      "ON_ERROR_STOP=1",
      "-q",
    ],
    input,
  );
  if (
    !output.includes(
      "PASS: all backend permission and privacy assertions passed",
    )
  )
    throw Error(output);
  console.log(
    "PASS: PostgreSQL 17 backend permission and privacy assertions. No cloud connection or personal data used.",
  );
} finally {
  try {
    run(["rm", "--force", "--volumes", name]);
  } catch {
    /* keep original failure */
  }
}
