import Dexie from "dexie";
export type SetLog = { weight: number; reps: number; done: boolean };
export type Exercise = {
  name: string;
  reps: string;
  sets: SetLog[];
  notes: string;
};
export type Plan = {
  day: number;
  name: string;
  time: string;
  duration: string;
  exercises: Exercise[];
  notes: string;
};
export type Session = {
  id: string;
  date: string;
  name: string;
  started: number;
  elapsed: number;
  runningSince: number | null;
  exercises: Exercise[];
  finished?: number;
};
export type Entry = { id: string; date: string; [key: string]: any };
export type State = {
  version: 1;
  profile: {
    name: string;
    height: number;
    weight: number;
    goal: string;
    protein: number;
    water: number;
    workEnd: string;
    workoutTime: string;
    frequency: number;
    exclusions: string;
  };
  language: "en" | "ar";
  plans: Plan[];
  sessions: Session[];
  active: Session | null;
  meals: Entry[];
  water: Entry[];
  sleep: Entry[];
  classes: Entry[];
  measurements: Entry[];
  foods: { name: string; protein: number | null }[];
};
export const dateKey = (d = new Date()) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
export const uid = () => crypto.randomUUID();
const ex = (name: string, reps: string): Exercise => ({
  name,
  reps,
  notes: "",
  sets: Array.from({ length: 2 }, () => ({
    weight: 0,
    reps: parseInt(reps),
    done: false,
  })),
});
export const initial = (): State => ({
  version: 1,
  profile: {
    name: "",
    height: 0,
    weight: 0,
    goal: "Build muscle, improve body composition, and become stronger.",
    protein: 85,
    water: 2000,
    workEnd: "15:00",
    workoutTime: "17:00",
    frequency: 3,
    exclusions: "Eggs, tuna",
  },
  language: "en",
  plans: [
    {
      day: 0,
      name: "Lower body",
      time: "17:00",
      duration: "50–60 min",
      exercises: [
        ex("Leg Press", "10–12"),
        ex("Hip Thrust", "10–12"),
        ex("Romanian Deadlift", "10"),
        ex("Leg Curl", "12"),
      ],
      notes: "",
    },
    {
      day: 1,
      name: "Rest",
      time: "17:00",
      duration: "Recovery",
      exercises: [],
      notes: "Optional gentle walking and recovery.",
    },
    {
      day: 2,
      name: "Upper body",
      time: "17:00",
      duration: "55 min",
      exercises: [
        ex("Lat Pulldown", "10–12"),
        ex("Seated Row", "10–12"),
        ex("Chest Press", "10"),
        ex("Shoulder Press", "10"),
      ],
      notes: "",
    },
    {
      day: 3,
      name: "Active recovery",
      time: "17:00",
      duration: "10–20 min",
      exercises: [],
      notes: "Optional walking, stretching, or mobility.",
    },
    {
      day: 4,
      name: "Full body",
      time: "17:00",
      duration: "50–60 min",
      exercises: [
        ex("Goblet Squat", "10"),
        ex("Glute Bridge", "12"),
        ex("Cable Row", "10"),
        ex("Chest Press", "10"),
        ex("Dead Bug", "8 per side"),
      ],
      notes:
        "Alternative: a beginner-friendly BodyPump class at a suitable intensity.",
    },
    {
      day: 5,
      name: "Rest",
      time: "17:00",
      duration: "Recovery",
      exercises: [],
      notes: "Recovery day.",
    },
    {
      day: 6,
      name: "Pool / Aqua",
      time: "17:00",
      duration: "20–30 min",
      exercises: [],
      notes: "Optional easy swimming or an Aqua class.",
    },
  ],
  sessions: [],
  active: null,
  meals: [],
  water: [],
  sleep: [],
  classes: [],
  measurements: [],
  foods: [
    "Greek yogurt with berries and oats",
    "Whole-grain toast with labneh and cucumber",
    "Cheese sandwich with vegetables",
    "Oatmeal with milk and banana",
    "Peanut butter and banana toast",
    "Grilled chicken with rice and vegetables",
    "Salmon with potatoes",
    "Chicken pasta",
    "Beef with rice and salad",
    "Lentil soup with bread and yogurt",
    "Chicken wrap",
    "Grilled fish with vegetables",
    "Turkey or chicken sandwich",
    "Chickpea and chicken salad",
    "Rice with grilled chicken",
    "Greek yogurt",
    "Fruit and nuts",
    "Dates",
    "Milk",
    "Cheese and crackers",
    "Protein smoothie",
  ].map((name) => ({ name, protein: null })),
});
export class Store extends Dexie {
  state!: Dexie.Table<{ id: string; value: State }, string>;
  constructor(name = "forme-private") {
    super(name);
    this.version(1).stores({ state: "id" });
  }
}
export const db = new Store();
export async function save(s: State) {
  await db.state.put({ id: "main", value: s });
}
export const duration = (s: Session, now = Date.now()) =>
  s.elapsed + (s.runningSince === null ? 0 : Math.max(0, now - s.runningSince));
export const weekStart = (d = new Date()) => {
  const v = new Date(d);
  v.setDate(v.getDate() - v.getDay());
  return dateKey(v);
};
export const sum = (entries: Entry[], field: string, date?: string) =>
  entries
    .filter((e) => !date || e.date === date)
    .reduce((n, e) => n + (Number(e[field]) || 0), 0);
export function validate(raw: unknown): State {
  const s = raw as State;
  if (
    !s ||
    s.version !== 1 ||
    !s.profile ||
    typeof s.profile.name !== "string" ||
    !["en", "ar"].includes(s.language) ||
    !Number.isFinite(s.profile.water) ||
    s.profile.water <= 0 ||
    !Number.isFinite(s.profile.protein) ||
    s.profile.protein <= 0
  )
    throw Error("Invalid profile or backup version.");
  for (const key of [
    "plans",
    "sessions",
    "meals",
    "water",
    "sleep",
    "classes",
    "measurements",
    "foods",
  ] as const)
    if (!Array.isArray(s[key])) throw Error(`Missing ${key}`);
  const validExercise = (e: Exercise) =>
    typeof e.name === "string" &&
    typeof e.reps === "string" &&
    typeof e.notes === "string" &&
    Array.isArray(e.sets) &&
    e.sets.every(
      (t) =>
        Number.isFinite(t.weight) &&
        t.weight >= 0 &&
        Number.isFinite(t.reps) &&
        t.reps >= 0 &&
        typeof t.done === "boolean",
    );
  if (
    s.plans.length !== 7 ||
    !s.plans.every(
      (p) =>
        Number.isInteger(p.day) &&
        p.day >= 0 &&
        p.day < 7 &&
        typeof p.name === "string" &&
        typeof p.time === "string" &&
        typeof p.duration === "string" &&
        typeof p.notes === "string" &&
        Array.isArray(p.exercises) &&
        p.exercises.every(validExercise),
    )
  )
    throw Error("Invalid workout plans");
  for (const x of [...s.sessions, ...(s.active ? [s.active] : [])])
    if (
      typeof x.id !== "string" ||
      !/^\d{4}-\d{2}-\d{2}$/.test(x.date) ||
      !Number.isFinite(x.started) ||
      !Number.isFinite(x.elapsed) ||
      x.elapsed < 0 ||
      (x.runningSince !== null && !Number.isFinite(x.runningSince)) ||
      !Array.isArray(x.exercises) ||
      !x.exercises.every(validExercise)
    )
      throw Error("Invalid workout session");
  for (const key of [
    "meals",
    "water",
    "sleep",
    "classes",
    "measurements",
  ] as const)
    for (const e of s[key]) {
      if (typeof e.id !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(e.date))
        throw Error("Invalid entry");
      if (key === "water" && (!Number.isFinite(e.ml) || e.ml <= 0))
        throw Error("Invalid water");
      if (
        key === "meals" &&
        (typeof e.name !== "string" ||
          !Number.isFinite(e.protein) ||
          e.protein < 0)
      )
        throw Error("Invalid meal");
      if (
        key === "sleep" &&
        (!Number.isFinite(e.hours) || e.hours < 0 || e.hours > 24)
      )
        throw Error("Invalid sleep");
      if (
        key === "classes" &&
        (typeof e.name !== "string" ||
          typeof e.time !== "string" ||
          typeof e.attended !== "boolean")
      )
        throw Error("Invalid class");
      if (key === "measurements" && (!Number.isFinite(e.value) || e.value <= 0))
        throw Error("Invalid measurement");
    }
  if (
    !s.foods.every(
      (f) =>
        typeof f.name === "string" &&
        (f.protein === null || (Number.isFinite(f.protein) && f.protein >= 0)),
    )
  )
    throw Error("Invalid food library");
  const validDate = (v: string) =>
    /^\d{4}-\d{2}-\d{2}$/.test(v) &&
    !Number.isNaN(new Date(v + "T12:00").getTime()) &&
    dateKey(new Date(v + "T12:00")) === v;
  const validTime = (v: string) => /^([01]\d|2[0-3]):[0-5]\d$/.test(v);
  if (
    !Number.isFinite(s.profile.height) ||
    (s.profile.height !== 0 && s.profile.height < 50) ||
    s.profile.height > 250 ||
    !Number.isFinite(s.profile.weight) ||
    (s.profile.weight !== 0 && s.profile.weight < 10) ||
    s.profile.weight > 500 ||
    !Number.isFinite(s.profile.frequency) ||
    s.profile.frequency < 1 ||
    s.profile.frequency > 7 ||
    typeof s.profile.goal !== "string" ||
    typeof s.profile.exclusions !== "string" ||
    !validTime(s.profile.workEnd) ||
    !validTime(s.profile.workoutTime)
  )
    throw Error("Invalid profile details");
  if (
    new Set(s.plans.map((x) => x.day)).size !== 7 ||
    s.plans.some((x) => !validTime(x.time))
  )
    throw Error("Invalid schedule");
  for (const key of [
    "sessions",
    "meals",
    "water",
    "sleep",
    "classes",
    "measurements",
  ] as const) {
    if (new Set(s[key].map((x) => x.id)).size !== s[key].length)
      throw Error("Duplicate record IDs");
    for (const e of s[key])
      if (!validDate(e.date)) throw Error("Invalid record date");
  }
  for (const e of s.classes)
    if (
      !validTime(e.time) ||
      !Number.isFinite(e.minutes) ||
      e.minutes <= 0 ||
      e.minutes > 300 ||
      typeof e.notes !== "string"
    )
      throw Error("Invalid class details");
  for (const e of s.sleep)
    if (
      !Number.isFinite(new Date(e.bed).getTime()) ||
      !Number.isFinite(new Date(e.wake).getTime()) ||
      e.quality < 1 ||
      e.quality > 5 ||
      !Number.isFinite(e.quality) ||
      !Number.isFinite(e.energy) ||
      e.energy < 1 ||
      e.energy > 5 ||
      Math.abs(
        (new Date(e.wake).getTime() - new Date(e.bed).getTime()) / 3600000 -
          e.hours,
      ) > 0.001
    )
      throw Error("Invalid sleep details");
  for (const e of s.meals)
    if (!["Breakfast", "Lunch", "Dinner", "Snacks"].includes(e.kind))
      throw Error("Invalid meal category");
  for (const e of s.measurements)
    if (typeof e.name !== "string" || !["cm", "kg"].includes(e.unit))
      throw Error("Invalid measurement details");
  return s;
}
