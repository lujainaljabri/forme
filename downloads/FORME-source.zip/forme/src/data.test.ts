import "fake-indexeddb/auto";
import { describe, it, expect } from "vitest";
import {
  Store,
  initial,
  dateKey,
  duration,
  sum,
  validate,
  weekStart,
} from "./data";
describe("private persisted tracking", () => {
  it("starts with profile and plans, with no invented history", () => {
    const s = initial();
    expect(s.profile.name).toBe("");
    expect(s.profile.height).toBe(0);
    expect(s.profile.weight).toBe(0);
    expect(s.plans.filter((p) => p.exercises.length)).toHaveLength(3);
    for (const k of [
      "sessions",
      "meals",
      "water",
      "sleep",
      "classes",
      "measurements",
    ] as const)
      expect(s[k]).toHaveLength(0);
    expect(s.foods.some((f) => /\b(eggs?|tuna)\b/i.test(f.name))).toBe(false);
  });
  it("recovers active workout weights and all logs after closing IndexedDB", async () => {
    const name = "test-" + Math.random();
    const d = new Store(name),
      s = initial();
    s.active = {
      id: "a",
      date: dateKey(),
      name: "Lower body",
      started: 1000,
      elapsed: 30000,
      runningSince: 40000,
      exercises: structuredClone(s.plans[0].exercises),
    };
    s.active.exercises[0].sets[0] = { weight: 42.5, reps: 11, done: true };
    s.water.push({ id: "w", date: dateKey(), ml: 250 });
    s.meals.push({
      id: "m",
      date: dateKey(),
      name: "Chicken",
      kind: "Lunch",
      protein: 31,
    });
    s.sleep.push({
      id: "s",
      date: dateKey(),
      hours: 8,
      bed: "2026-11-13T23:00",
      wake: "2026-11-14T07:00",
      quality: 4,
      energy: 4,
    });
    s.classes.push({
      id: "c",
      date: dateKey(),
      time: "17:00",
      name: "Aqua",
      minutes: 45,
      attended: true,
      notes: "",
    });
    await d.state.put({ id: "main", value: s });
    d.close();
    const reopened = new Store(name);
    const v = (await reopened.state.get("main"))!.value;
    expect(v.active!.exercises[0].sets[0].weight).toBe(42.5);
    expect(v.meals[0].protein).toBe(31);
    expect(sum(v.water, "ml", dateKey())).toBe(250);
    expect(v.sleep[0].hours).toBe(8);
    expect(v.classes[0].attended).toBe(true);
    expect(validate(JSON.parse(JSON.stringify(v)))).toEqual(v);
    await reopened.delete();
  });
  it("calculates elapsed time across pause, resume, and reopening", () => {
    const s = {
      id: "a",
      date: "2026-11-14",
      name: "Test",
      started: 1000,
      elapsed: 20000,
      runningSince: 100000,
      exercises: [],
    };
    expect(duration(s, 115000)).toBe(35000);
    s.elapsed = duration(s, 115000);
    s.runningSince = null as any;
    expect(duration(s, 999999)).toBe(35000);
    s.runningSince = 200000;
    expect(duration(s, 210000)).toBe(45000);
  });
  it("keeps daily sums and local Sunday boundaries correct", () => {
    expect(
      sum(
        [
          { id: "1", date: "2026-11-14", ml: 250 },
          { id: "2", date: "2026-11-14", ml: 500 },
          { id: "3", date: "2026-11-13", ml: 150 },
        ],
        "ml",
        "2026-11-14",
      ),
    ).toBe(750);
    expect(weekStart(new Date(2026, 10, 14, 23))).toBe("2026-11-08");
    expect(dateKey(new Date(2026, 0, 2, 0, 1))).toBe("2026-01-02");
  });
  it("rejects incomplete, incompatible, or corrupt backups", () => {
    expect(() => validate({ version: 2 })).toThrow();
    const s = initial();
    expect(validate(s)).toEqual(s);
    s.water.push({ id: "bad", date: "2026-11-14", ml: -1 });
    expect(() => validate(s)).toThrow();
    s.water = [];
    s.plans[0].exercises[0].sets[0].weight = NaN;
    expect(() => validate(s)).toThrow();
  });
  it("round-trips finished sessions and edits through backup restore", async () => {
    const s = initial();
    s.sessions.push({
      id: "finished",
      date: "2026-11-14",
      name: "Lower",
      started: 1000,
      elapsed: 60000,
      runningSince: null,
      finished: 61000,
      exercises: s.plans[0].exercises,
    });
    s.sessions[0].exercises[0].sets[0] = { weight: 20, reps: 10, done: true };
    const restored = validate(JSON.parse(JSON.stringify(s)));
    expect(restored.sessions[0].elapsed).toBe(60000);
    expect(restored.sessions[0].exercises[0].sets[0]).toEqual({
      weight: 20,
      reps: 10,
      done: true,
    });
  });
});
