import { ExerciseArt, cues } from "./exercises";
import React, { useState, useEffect, useRef } from "react";
import { createRoot } from "react-dom/client";
import {
  Home,
  Dumbbell,
  Plus,
  ChartNoAxesCombined,
  Grid2X2,
  ArrowUpRight,
  ChevronRight,
  Droplets,
  Flame,
  Moon,
  Calendar,
  Play,
  Pause,
  Check,
  X,
  Download,
  Upload,
  Trash2,
  Heart,
  Utensils,
  Settings,
  ArrowLeft,
  Timer,
  ShieldCheck,
} from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  Tooltip,
  LineChart,
  Line,
  CartesianGrid,
} from "recharts";
import {
  db,
  save,
  initial,
  dateKey,
  uid,
  duration,
  weekStart,
  sum,
  validate,
  type State,
  type Plan,
  type Session,
  type Entry,
} from "./data";
import "@fontsource/inter/latin-400.css";
import "@fontsource/inter/latin-500.css";
import "@fontsource/playfair-display/latin-400.css";
import "./style.css";
const days = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];
const arDays = [
  "الأحد",
  "الإثنين",
  "الثلاثاء",
  "الأربعاء",
  "الخميس",
  "الجمعة",
  "السبت",
];
const classInfo = [
  [
    "BodyPump",
    "Strength endurance",
    "Modified full-body option; start with light loads.",
    "Moderate–high",
    "45–60",
  ],
  [
    "Aqua",
    "Water fitness",
    "Low-impact movement in the pool.",
    "Low–moderate",
    "30–45",
  ],
  ["BodyCombat", "Cardio", "Martial arts inspired cardio.", "High", "45–60"],
  [
    "RPM",
    "Cycling",
    "Indoor cycling at your own resistance.",
    "Moderate–high",
    "30–45",
  ],
  ["Zumba", "Dance", "Rhythmic dance cardio.", "Moderate", "45–60"],
  [
    "Cardio Step",
    "Cardio",
    "Step-based cardio and coordination.",
    "Moderate–high",
    "45–60",
  ],
  [
    "BodyFlow",
    "Recovery",
    "Mobility, flexibility and mind-body movement.",
    "Low–moderate",
    "45–60",
  ],
  [
    "HYROX / Les Mills Ceremony",
    "Conditioning",
    "Demanding conditioning; not a beginner default.",
    "High",
    "45–60",
  ],
  [
    "Challenge",
    "Mixed",
    "Ask the instructor about the format and modifications.",
    "Varies",
    "30–60",
  ],
];
type Field = {
  key: string;
  label: string;
  type?: string;
  value?: any;
  options?: string[];
  min?: number;
  max?: number;
  required?: boolean;
};
type Modal = { title: string; fields: Field[]; onSave: (v: any) => void };
const fmt = (ms: number) => {
  const n = Math.floor(ms / 1000);
  return `${String(Math.floor(n / 60)).padStart(2, "0")}:${String(n % 60).padStart(2, "0")}`;
};
function App() {
  const [s, S] = useState<State | null>(null),
    [page, P] = useState("Home"),
    [modal, M] = useState<Modal | null>(null),
    [error, E] = useState(""),
    [ready, R] = useState(false),
    [now, N] = useState(Date.now()),
    [rest, Rest] = useState<number | null>(null),
    [period, Period] = useState("week");
  useEffect(() => {
    document.documentElement.lang = s?.language || "en";
    document.documentElement.dir = s?.language === "ar" ? "rtl" : "ltr";
  }, [s?.language]);
  useEffect(() => {
    const close = (e: KeyboardEvent) => {
      if (e.key === "Escape") M(null);
    };
    document.addEventListener("keydown", close);
    return () => document.removeEventListener("keydown", close);
  }, []);
  const queue = useRef(Promise.resolve());
  const latest = useRef<State | null>(null);
  const file = useRef<HTMLInputElement>(null);
  useEffect(() => {
    db.state
      .get("main")
      .then((r) => {
        const v = r?.value || initial();
        latest.current = v;
        S(v);
        R(true);
      })
      .catch(() =>
        E(
          "Storage could not open. Allow website storage in Safari and reload.",
        ),
      );
    const t = setInterval(() => N(Date.now()), 500);
    const offlineError = () =>
      E(
        "Offline files could not be cached. Keep a connection and reload to try again.",
      );
    window.addEventListener("forme-offline-error", offlineError);
    return () => {
      clearInterval(t);
      window.removeEventListener("forme-offline-error", offlineError);
    };
  }, []);
  const update = (fn: (v: State) => void) => {
    if (!latest.current) return;
    const v = structuredClone(latest.current);
    fn(v);
    latest.current = v;
    S(v);
    queue.current = queue.current
      .then(() => save(v))
      .catch(() =>
        E(
          "Your latest change could not be saved. Back up now and check available storage.",
        ),
      );
  };
  if (!s)
    return (
      <main className="loading">
        <h1>FORME</h1>
        <p>{error || "Strength in Your Own Way"}</p>
      </main>
    );
  const ar = s.language === "ar",
    t = (en: string, arabic: string) => (ar ? arabic : en),
    today = dateKey(),
    basePlan = s.plans.find((p) => p.day === new Date().getDay())!,
    replacement = s.classes.find(
      (x) => x.date === today && x.replace === "Yes",
    ),
    plan: Plan = replacement
      ? {
          ...basePlan,
          name: replacement.name,
          time: replacement.time,
          duration: `${replacement.minutes} min`,
          exercises: [],
          notes: t(
            "Your personally scheduled class replaces today’s workout.",
            "حصتك المجدولة تحل محل تمرين اليوم.",
          ),
        }
      : basePlan,
    water = sum(s.water, "ml", today),
    protein = sum(s.meals, "protein", today),
    latestSleep = s.sleep
      .slice()
      .sort((a, b) => String(b.wake).localeCompare(String(a.wake)))[0],
    weekly = s.sessions.filter((x) => x.date >= weekStart() && x.date <= today),
    upcoming = s.classes
      .filter((x) => !x.attended && `${x.date}T${x.time}` >= `${today}T00:00`)
      .sort((a, b) =>
        `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`),
      )[0];
  const add = (
    key: "water" | "meals" | "sleep" | "classes" | "measurements",
    v: any,
    id?: string,
  ) =>
    update((d) => {
      const a = d[key];
      const e = { ...v, id: id || uid() };
      const i = a.findIndex((x) => x.id === id);
      if (i >= 0) a[i] = e;
      else a.push(e);
    });
  const remove = (
    key: "water" | "meals" | "sleep" | "classes" | "measurements" | "sessions",
    id: string,
  ) => {
    if (confirm(t("Delete this entry?", "حذف هذا السجل؟")))
      update((d) => {
        (d[key] as Entry[]) = d[key].filter((x) => x.id !== id);
      });
  };
  const waterForm = (e?: Entry) =>
    M({
      title: t("Add water", "إضافة ماء"),
      fields: [
        {
          key: "date",
          label: t("Date", "التاريخ"),
          type: "date",
          value: e?.date || today,
        },
        {
          key: "ml",
          label: t("Amount · ml", "الكمية · مل"),
          type: "number",
          min: 1,
          max: 10000,
          value: e?.ml || 250,
        },
      ],
      onSave: (v) => add("water", { ...v, ml: +v.ml }, e?.id),
    });
  const mealForm = (e?: Entry) =>
    M({
      title: t("Log a meal", "تسجيل وجبة"),
      fields: [
        {
          key: "date",
          label: t("Date", "التاريخ"),
          type: "date",
          value: e?.date || today,
        },
        {
          key: "kind",
          label: t("Meal", "الوجبة"),
          options: ["Breakfast", "Lunch", "Dinner", "Snacks"],
          value: e?.kind,
        },
        {
          key: "name",
          label: t(
            "Food · choose or enter your own",
            "الطعام · اختر أو أدخل اسمًا",
          ),
          type: "food",
          value: e?.name,
        },
        {
          key: "protein",
          label: t(
            "Estimated protein · g (your input)",
            "البروتين التقديري · غ (إدخالك)",
          ),
          type: "number",
          min: 0,
          max: 500,
          value: e?.protein || 0,
        },
      ],
      onSave: (v) => {
        if (excluded(v.name)) {
          E("This food conflicts with your dietary exclusions.");
          return;
        }
        add("meals", { ...v, protein: +v.protein }, e?.id);
      },
    });
  const sleepForm = (e?: Entry) =>
    M({
      title: t("Log your rest", "تسجيل النوم"),
      fields: [
        {
          key: "bed",
          label: t("Bedtime", "وقت النوم"),
          type: "datetime-local",
          value: e?.bed || `${today}T23:00`,
        },
        {
          key: "wake",
          label: t("Wake-up", "وقت الاستيقاظ"),
          type: "datetime-local",
          value: e?.wake || `${dateKey(new Date(Date.now() + 86400000))}T07:00`,
        },
        {
          key: "quality",
          label: t("Sleep quality · 1–5", "جودة النوم · ١–٥"),
          type: "number",
          min: 1,
          max: 5,
          value: e?.quality || 3,
        },
        {
          key: "energy",
          label: t("Energy · 1–5", "الطاقة · ١–٥"),
          type: "number",
          min: 1,
          max: 5,
          value: e?.energy || 3,
        },
      ],
      onSave: (v) => {
        const hours =
          (new Date(v.wake).getTime() - new Date(v.bed).getTime()) / 3600000;
        if (hours <= 0 || hours > 24) {
          E("Wake-up must follow bedtime, within 24 hours.");
          return;
        }
        add(
          "sleep",
          {
            ...v,
            date: v.wake.slice(0, 10),
            hours,
            quality: +v.quality,
            energy: +v.energy,
          },
          e?.id,
        );
      },
    });
  const classForm = (name = classInfo[0][0], e?: Entry) =>
    M({
      title: t("Schedule a class", "جدولة حصة"),
      fields: [
        {
          key: "name",
          label: t("Class", "الحصة"),
          options: classInfo.map((x) => x[0]),
          value: e?.name || name,
        },
        {
          key: "date",
          label: t("Date", "التاريخ"),
          type: "date",
          value: e?.date || today,
        },
        {
          key: "time",
          label: t("Time", "الوقت"),
          type: "time",
          value: e?.time || "17:00",
        },
        {
          key: "minutes",
          label: t("Duration · minutes", "المدة · دقيقة"),
          type: "number",
          min: 1,
          max: 300,
          value: e?.minutes || 45,
        },
        {
          key: "notes",
          label: t("Personal notes", "ملاحظات شخصية"),
          value: e?.notes || "",
          required: false,
        },
        {
          key: "replace",
          label: t(
            "Replace this day’s planned workout?",
            "استبدال تمرين هذا اليوم؟",
          ),
          options: ["No", "Yes"],
          value: e?.replace || "No",
        },
      ],
      onSave: (v) => {
        add(
          "classes",
          { ...v, minutes: +v.minutes, attended: e?.attended || false },
          e?.id,
        );
      },
    });
  const start = (p: Plan) => {
    if (s.active) {
      P("Track");
      return;
    }
    update((d) => {
      d.active = {
        id: uid(),
        date: today,
        name: p.name,
        started: Date.now(),
        elapsed: 0,
        runningSince: Date.now(),
        exercises: structuredClone(p.exercises),
      };
    });
    P("Track");
  };
  const editPlan = (p: Plan) =>
    M({
      title: t("Edit your plan", "تعديل الخطة"),
      fields: [
        {
          key: "day",
          label: t("Day · swaps schedules", "اليوم · تبديل الجدول"),
          options: days,
          value: days[p.day],
        },
        {
          key: "name",
          label: t("Workout / activity", "التمرين / النشاط"),
          value: p.name,
        },
        {
          key: "time",
          label: t("Start time", "وقت البدء"),
          type: "time",
          value: p.time,
        },
        { key: "duration", label: t("Duration", "المدة"), value: p.duration },
        {
          key: "notes",
          label: t("Notes", "ملاحظات"),
          value: p.notes,
          required: false,
        },
      ],
      onSave: (v) =>
        update((d) => {
          const target = days.indexOf(v.day),
            sourceIndex = d.plans.findIndex((x) => x.day === p.day),
            targetIndex = d.plans.findIndex((x) => x.day === target);
          if (target !== p.day) d.plans[targetIndex].day = p.day;
          d.plans[sourceIndex] = { ...d.plans[sourceIndex], ...v, day: target };
          d.plans.sort((a, b) => a.day - b.day);
        }),
    });
  const exerciseForm = (
    target: "plan" | "active",
    day: number,
    index?: number,
  ) => {
    const p =
      target === "active" ? s.active! : s.plans.find((x) => x.day === day)!;
    const ex = index === undefined ? null : p.exercises[index];
    M({
      title: t("Exercise details", "تفاصيل التمرين"),
      fields: [
        {
          key: "name",
          label: t("Exercise name", "اسم التمرين"),
          value: ex?.name || "",
        },
        {
          key: "reps",
          label: t("Target reps", "التكرارات المستهدفة"),
          value: ex?.reps || "10–12",
        },
        {
          key: "count",
          label: t("Number of sets", "عدد المجموعات"),
          type: "number",
          min: 1,
          max: 12,
          value: ex?.sets.length || 2,
        },
        {
          key: "notes",
          label: t("Personal notes", "ملاحظات شخصية"),
          value: ex?.notes || "",
          required: false,
        },
      ],
      onSave: (v) =>
        update((d) => {
          const p =
            target === "active"
              ? d.active!
              : d.plans.find((x) => x.day === day)!;
          const old = index === undefined ? undefined : p.exercises[index];
          const x = {
            name: v.name,
            reps: v.reps,
            notes: v.notes,
            sets: Array.from(
              { length: +v.count },
              (_, i) =>
                old?.sets[i] || {
                  weight: 0,
                  reps: parseInt(v.reps) || 10,
                  done: false,
                },
            ),
          };
          if (index === undefined) p.exercises.push(x);
          else p.exercises[index] = x;
        }),
    });
  };
  const excluded = (name: string) =>
    /\b(eggs?|tuna)\b|بيض|تونة/i.test(name) ||
    s.profile.exclusions
      .split(/[,،]/)
      .map((x) => x.trim().toLowerCase())
      .filter(Boolean)
      .some((x) => name.toLowerCase().includes(x));
  const quickWater = (ml: number) =>
    add("water", { date: today, ml, timestamp: Date.now() });
  const icon = (I: any) => <I size={20} strokeWidth={1.6} />;
  const empty = (text: string) => (
    <div className="empty">
      <Heart size={24} />
      <p>{text}</p>
    </div>
  );
  const heading = (eyebrow: string, title: string, description?: string) => (
    <div className="page-heading">
      <span className="eyebrow">{eyebrow}</span>
      <h1>{title}</h1>
      {description && <p>{description}</p>}
    </div>
  );
  const records = (
    key: "water" | "meals" | "sleep" | "classes" | "measurements",
    edit: (e: Entry) => void,
  ) => (
    <div className="records">
      {s[key]
        .slice()
        .sort((a, b) => b.date.localeCompare(a.date))
        .map((e) => (
          <div className="record" key={e.id}>
            <button className="record-main" onClick={() => edit(e)}>
              <strong>
                {key === "water"
                  ? `${e.ml} ml`
                  : key === "meals"
                    ? e.name
                    : key === "sleep"
                      ? `${e.hours.toFixed(1)} h`
                      : key === "measurements"
                        ? `${e.name}: ${e.value} ${e.unit}`
                        : e.name}
              </strong>
              <small>
                {e.date}
                {key === "meals"
                  ? ` · ${e.kind} · ${e.protein} g`
                  : key === "classes"
                    ? ` · ${e.time}${e.attended ? " · Attended" : ""}`
                    : ""}
              </small>
            </button>
            {key === "classes" && (
              <>
                <button
                  className="icon-button"
                  aria-label="Export to calendar"
                  onClick={() => calendar(e)}
                >
                  <Calendar size={17} />
                </button>
                <button
                  className={`icon-button ${e.attended ? "checked" : ""}`}
                  aria-label="Toggle attendance"
                  onClick={() =>
                    update((d) => {
                      const c = d.classes.find((x) => x.id === e.id)!;
                      c.attended = !c.attended;
                    })
                  }
                >
                  <Check size={18} />
                </button>
              </>
            )}
            <button
              className="icon-button"
              aria-label="Delete entry"
              onClick={() => remove(key, e.id)}
            >
              <Trash2 size={16} />
            </button>
          </div>
        ))}
    </div>
  );
  const download = (
    content: string,
    name: string,
    type = "application/json",
  ) => {
    const url = URL.createObjectURL(new Blob([content], { type }));
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  const calendar = (e: Entry) => {
    const begin = new Date(`${e.date}T${e.time}`),
      end = new Date(begin.getTime() + e.minutes * 60000);
    const ics = (d: Date) =>
      d
        .toISOString()
        .replace(/[-:]/g, "")
        .replace(/\.\d{3}/, "");
    download(
      `BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//FORME//Personal Classes//EN\r\nBEGIN:VEVENT\r\nUID:${e.id}@forme\r\nDTSTAMP:${ics(new Date())}\r\nDTSTART:${ics(begin)}\r\nDTEND:${ics(end)}\r\nSUMMARY:FORME ${e.name}\r\nEND:VEVENT\r\nEND:VCALENDAR`,
      "forme-class.ics",
      "text/calendar",
    );
  };
  const active = s.active,
    total = active?.exercises.reduce((n, e) => n + e.sets.length, 0) || 0,
    done =
      active?.exercises.reduce(
        (n, e) => n + e.sets.filter((x) => x.done).length,
        0,
      ) || 0;
  return (
    <div className="app" dir={ar ? "rtl" : "ltr"}>
      <aside className="sidebar">
        <a className="wordmark" onClick={() => P("Home")}>
          FORME<span>STRENGTH IN YOUR OWN WAY</span>
        </a>
        <div className="sidebar-caption">
          {t("YOUR PERSONAL SPACE", "مساحتك الخاصة")}
        </div>
        {["Home", "Workout Plan", "Track", "Progress", "More"].map((p, i) => (
          <button
            className={page === p ? "selected" : ""}
            onClick={() => P(p)}
            key={p}
          >
            {icon([Home, Dumbbell, Plus, ChartNoAxesCombined, Grid2X2][i])}
            {t(p, ["الرئيسية", "خطة التمرين", "تسجيل", "التقدم", "المزيد"][i])}
            {p === "Track" && active && <i />}
          </button>
        ))}
        <div className="sidebar-bottom">
          <ShieldCheck size={19} />
          <span>
            {t("Just you. On your device.", "لك وحدك. على جهازك.")}
            <small>{t("Private by design", "خصوصية من الأساس")}</small>
          </span>
        </div>
      </aside>
      <div className="body">
        <header>
          <div className="mobile-logo">FORME</div>
          <span className="header-date">
            {new Date().toLocaleDateString(ar ? "ar-OM" : "en-GB", {
              weekday: "long",
              day: "numeric",
              month: "long",
            })}
          </span>
          <div className="header-right">
            <button
              className="language"
              onClick={() =>
                update((d) => {
                  d.language = ar ? "en" : "ar";
                })
              }
            >
              {ar ? "EN" : "العربية"}
            </button>
            <button
              className="avatar"
              onClick={() => P("Settings")}
              aria-label="Open profile"
            >
              {s.profile.name.slice(0, 1) || "F"}
            </button>
          </div>
        </header>
        <main>
          {error && (
            <div className="error" role="alert">
              {error}
              <button onClick={() => E("")} aria-label="Dismiss">
                <X size={18} />
              </button>
            </div>
          )}
          {page === "Home" && (
            <>
              {heading(
                t("A LITTLE STRONGER, EVERY DAY", "أقوى قليلًا، كل يوم"),
                t(
                  s.profile.name
                    ? `Welcome back, ${s.profile.name} 🤍`
                    : "Welcome to FORME 🤍",
                  s.profile.name
                    ? `أهلًا بعودتك، ${s.profile.name} 🤍`
                    : "أهلًا بك في FORME 🤍",
                ),
                t(
                  "Your space to move, nourish, and feel your best.",
                  "مساحتك للحركة والتغذية والشعور بأفضل حال.",
                ),
              )}
              {!s.profile.name && (
                <div className="notice">
                  <strong>
                    {t(
                      "Your private profile starts here.",
                      "ملفك الخاص يبدأ هنا.",
                    )}
                  </strong>
                  <p>
                    {t(
                      "Import your private setup JSON from Backup, or enter your profile on this device.",
                      "استوردي ملف الإعداد الخاص من النسخ الاحتياطي أو أدخلي بياناتك على هذا الجهاز.",
                    )}
                  </p>
                  <div className="actions">
                    <button className="primary" onClick={() => P("Settings")}>
                      {t("Set up profile", "إعداد الملف")}
                    </button>
                    <button className="secondary" onClick={() => P("Backup")}>
                      {t("Import private setup", "استيراد إعداد خاص")}
                    </button>
                  </div>
                </div>
              )}
              <div className="home-grid">
                <section className="hero card">
                  <div className="hero-orbit" />
                  <span className="eyebrow">
                    {t("YOUR MOVEMENT, YOUR MOMENT", "حركتك، لحظتك")}
                  </span>
                  <div className="hero-copy">
                    <div className="pill">
                      <span />
                      {t("TODAY’S PLAN", "خطة اليوم")}
                    </div>
                    <h2>{plan.name}</h2>
                    <p>
                      {plan.exercises.length
                        ? t(
                            "Show up for yourself. Strength follows.",
                            "امنحي نفسك الوقت، والقوة ستأتي.",
                          )
                        : plan.notes}
                    </p>
                    <div className="hero-details">
                      <span>
                        <Calendar size={15} />
                        {plan.time} · {plan.duration}
                      </span>
                      <span>
                        <Dumbbell size={15} />
                        {plan.exercises.length} {t("exercises", "تمارين")}
                      </span>
                    </div>
                    <button
                      className="primary ivory"
                      onClick={() => start(plan)}
                    >
                      <Play size={16} fill="currentColor" />
                      {active
                        ? t("Resume workout", "متابعة التمرين")
                        : t("Start workout", "بدء التمرين")}
                      <ArrowUpRight size={18} />
                    </button>
                  </div>
                  <div className="hero-art">
                    <div className="monogram">f</div>
                    <span>IN YOUR OWN WAY</span>
                  </div>
                </section>
                <section className="card weekly">
                  <div className="section-label">
                    {t("THIS WEEK", "هذا الأسبوع")}
                    <Dumbbell size={18} />
                  </div>
                  <h3>
                    {weekly.length}
                    <span> / {s.profile.frequency}</span>
                  </h3>
                  <p>{t("workouts completed", "تمارين مكتملة")}</p>
                  <div className="week-dots">
                    {days.map((d, i) => {
                      const dt = new Date(`${weekStart()}T12:00`);
                      dt.setDate(dt.getDate() + i);
                      return (
                        <div key={d}>
                          <span
                            className={
                              weekly.some((x) => x.date === dateKey(dt))
                                ? "complete"
                                : i === new Date().getDay()
                                  ? "current"
                                  : ""
                            }
                          >
                            {weekly.some((x) => x.date === dateKey(dt)) ? (
                              <Check size={14} />
                            ) : (
                              d[0]
                            )}
                          </span>
                          <small>{t(d.slice(0, 3), arDays[i])}</small>
                        </div>
                      );
                    })}
                  </div>
                  <div className="soft-note">
                    {t(
                      "Consistency over perfection. Always.",
                      "الاستمرارية قبل المثالية. دائمًا.",
                    )}
                  </div>
                </section>
                <section className="card metric">
                  <div className="section-label">
                    {t("DAILY NOURISHMENT", "تغذية اليوم")}
                    <Utensils size={18} />
                  </div>
                  <div className="metric-content">
                    <div>
                      <h3>
                        {protein}
                        <span> g</span>
                      </h3>
                      <p>
                        {t(
                          `of ${s.profile.protein} g protein`,
                          `من ${s.profile.protein} غ بروتين`,
                        )}
                      </p>
                      <button
                        className="text-button"
                        onClick={() => mealForm()}
                      >
                        {t("Log a meal", "تسجيل وجبة")}
                        <Plus size={15} />
                      </button>
                    </div>
                    <div
                      className="ring mauve"
                      style={
                        {
                          "--progress": `${Math.min(100, (protein / s.profile.protein) * 100)}%`,
                        } as React.CSSProperties
                      }
                    >
                      <Utensils size={25} />
                    </div>
                  </div>
                  <div className="bar">
                    <i
                      style={{
                        width: `${Math.min(100, (protein / s.profile.protein) * 100)}%`,
                      }}
                    />
                  </div>
                  <small>
                    {t(
                      "Fuel your strength. Nourish your recovery.",
                      "غذّي قوتك وادعمي تعافيك.",
                    )}
                  </small>
                </section>
                <section className="card metric water-card">
                  <div className="section-label">
                    {t("A MOMENT TO HYDRATE", "لحظة للترطيب")}
                    <Droplets size={18} />
                  </div>
                  <div className="metric-content">
                    <div>
                      <h3>
                        {(water / 1000).toFixed(2)}
                        <span> L</span>
                      </h3>
                      <p>
                        {t(
                          `of ${s.profile.water / 1000} L daily goal`,
                          `من هدفك اليومي ${s.profile.water / 1000} لتر`,
                        )}
                      </p>
                    </div>
                    <div
                      className="ring blue"
                      style={
                        {
                          "--progress": `${Math.min(100, (water / s.profile.water) * 100)}%`,
                        } as React.CSSProperties
                      }
                    >
                      <Droplets size={27} />
                    </div>
                  </div>
                  <div className="water-buttons">
                    {[150, 250, 500].map((n) => (
                      <button key={n} onClick={() => quickWater(n)}>
                        + {n} ml
                      </button>
                    ))}
                  </div>
                </section>
              </div>
              <div className="section-heading">
                <h2>{t("Make time for you", "وقت لنفسك")}</h2>
                <span>
                  {t("THE LITTLE THINGS ADD UP", "التفاصيل الصغيرة تصنع الفرق")}
                </span>
              </div>
              <div className="quick-grid">
                {[
                  [Utensils, t("Log meal", "تسجيل وجبة"), () => mealForm()],
                  [Droplets, t("Add water", "إضافة ماء"), () => waterForm()],
                  [Calendar, t("Add class", "إضافة حصة"), () => classForm()],
                  [Moon, t("Log sleep", "تسجيل نوم"), () => sleepForm()],
                ].map(([I, label, fn], i) => (
                  <button
                    className="card quick"
                    key={i}
                    onClick={fn as () => void}
                  >
                    {icon(I)}
                    <span>{label as string}</span>
                    <Plus size={16} />
                  </button>
                ))}
              </div>
              <div className="lower-grid">
                <section className="card upcoming">
                  <div className="section-label">
                    {t("NEXT ON YOUR CALENDAR", "القادم في تقويمك")}
                    <Calendar size={18} />
                  </div>
                  {upcoming ? (
                    <>
                      <h2>{upcoming.name}</h2>
                      <p>
                        {upcoming.date} · {upcoming.time}
                      </p>
                    </>
                  ) : (
                    <>
                      <h2>
                        {t("Room for something new", "مساحة لتجربة جديدة")}
                      </h2>
                      <p>
                        {t(
                          "A little movement, a change of pace. Add a class when it suits you.",
                          "أضيفي حصة في الوقت الذي يناسبك.",
                        )}
                      </p>
                    </>
                  )}
                  <button className="text-button" onClick={() => P("Classes")}>
                    {t("Explore classes", "استكشاف الحصص")}
                    <ArrowUpRight size={17} />
                  </button>
                </section>
                <section className="quote card">
                  <Heart size={22} />
                  <blockquote>
                    {t(
                      "“You don’t have to be perfect. Just keep showing up for yourself.”",
                      "«لا تحتاجين إلى المثالية. واصلي الاهتمام بنفسك.»",
                    )}
                  </blockquote>
                  <span>STRENGTH IN YOUR OWN WAY</span>
                </section>
              </div>
            </>
          )}
          {page === "Workout Plan" && (
            <>
              {heading(
                t("BUILT AROUND YOUR LIFE", "مصممة لحياتك"),
                t("Your weekly rhythm", "إيقاعك الأسبوعي"),
                t(
                  "Three strength days. Space to recover. Everything is editable.",
                  "ثلاثة أيام قوة ومساحة للتعافي. يمكنك تعديل كل شيء.",
                ),
              )}
              <div className="notice">
                {t(
                  "Warm up 5–8 minutes with easy walking and light practice sets. Cool down with gentle movement and comfortable stretches.",
                  "إحماء ٥–٨ دقائق بالمشي ومجموعات خفيفة. اختتمي بحركة هادئة وتمدد مريح.",
                )}
              </div>
              <div className="plan-list">
                {s.plans.map((p) => (
                  <section
                    key={p.day}
                    className={`card plan-card ${p.day === new Date().getDay() ? "today" : ""}`}
                  >
                    <div className="plan-top">
                      <div>
                        <span className="eyebrow">
                          {ar ? arDays[p.day] : days[p.day]}{" "}
                          {p.day === new Date().getDay()
                            ? t(" · TODAY", " · اليوم")
                            : ""}
                        </span>
                        <h2>{p.name}</h2>
                        <p>
                          {p.time} · {p.duration}
                        </p>
                      </div>
                      <button className="secondary" onClick={() => editPlan(p)}>
                        {t("Edit / reschedule", "تعديل / نقل")}
                      </button>
                    </div>
                    {p.exercises.map((e, i) => (
                      <div className="exercise-preview" key={i}>
                        <ExerciseArt name={e.name} />
                        <button onClick={() => exerciseForm("plan", p.day, i)}>
                          <strong>{e.name}</strong>
                          <small>
                            {e.sets.length} × {e.reps} {t("reps", "تكرارات")}
                            {e.notes && ` · ${e.notes}`}
                          </small>
                          {cues[e.name] && (
                            <small className="exercise-cue">
                              {cues[e.name][ar ? 1 : 0]}
                            </small>
                          )}
                        </button>
                        <button
                          aria-label="Remove exercise"
                          className="icon-button"
                          onClick={() =>
                            update((d) => {
                              d.plans
                                .find((x) => x.day === p.day)!
                                .exercises.splice(i, 1);
                            })
                          }
                        >
                          <X size={16} />
                        </button>
                      </div>
                    ))}
                    {p.notes && <p>{p.notes}</p>}
                    <div className="actions">
                      <button
                        className="text-button"
                        onClick={() => exerciseForm("plan", p.day)}
                      >
                        <Plus size={16} />
                        {t("Add exercise", "إضافة تمرين")}
                      </button>
                      <button className="primary" onClick={() => start(p)}>
                        <Play size={15} />
                        {t("Start session", "بدء جلسة")}
                      </button>
                    </div>
                  </section>
                ))}
              </div>
            </>
          )}
          {page === "Track" && (
            <>
              {heading(
                t("ONE SET AT A TIME", "مجموعة تلو الأخرى"),
                active ? active.name : t("Your training space", "مساحة تدريبك"),
              )}
              {active ? (
                <>
                  <div className="card live-summary">
                    <div>
                      <span className="eyebrow">
                        {active.runningSince === null
                          ? t("PAUSED", "متوقف")
                          : t("SESSION IN PROGRESS", "جلسة جارية")}
                      </span>
                      <h2 className="timer">{fmt(duration(active, now))}</h2>
                    </div>
                    <button
                      className="secondary"
                      onClick={() =>
                        update((d) => {
                          const a = d.active!;
                          if (a.runningSince !== null) {
                            a.elapsed = duration(a);
                            a.runningSince = null;
                          } else a.runningSince = Date.now();
                        })
                      }
                    >
                      {active.runningSince === null ? (
                        <Play size={18} />
                      ) : (
                        <Pause size={18} />
                      )}
                    </button>
                    <div className="session-progress">
                      <strong>
                        {done} / {total} {t("sets", "مجموعات")}
                      </strong>
                      <div className="bar">
                        <i
                          style={{
                            width: `${total ? (done / total) * 100 : 0}%`,
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="notice">
                    {t(
                      "Warm up for 5–8 minutes. Use comfortable loads and controlled movement.",
                      "ابدئي بإحماء ٥–٨ دقائق. اختاري أوزانًا مريحة وحركة متحكمًا بها.",
                    )}
                  </div>
                  <section className="rest-strip">
                    <Timer size={20} />
                    <span>
                      {rest && rest > now
                        ? `${t("Rest", "راحة")} ${fmt(rest - now)}`
                        : t(
                            "Ready for your next set?",
                            "جاهزة للمجموعة التالية؟",
                          )}
                    </span>
                    {[60, 90, 120].map((n) => (
                      <button
                        key={n}
                        onClick={() => Rest(Date.now() + n * 1000)}
                      >
                        {n}s
                      </button>
                    ))}
                    {rest && (
                      <button
                        onClick={() => Rest(null)}
                        aria-label="Cancel rest"
                      >
                        <X size={16} />
                      </button>
                    )}
                  </section>
                  {active.exercises.map((e, i) => {
                    const prev = [...s.sessions]
                      .reverse()
                      .flatMap((x) => x.exercises)
                      .find((x) => x.name === e.name);
                    return (
                      <section className="card live-exercise" key={i}>
                        <div className="exercise-title">
                          <ExerciseArt name={e.name} />
                          <div>
                            <h2>{e.name}</h2>
                            <p>
                              {t("Target", "الهدف")}: {e.reps} ·{" "}
                              {t("Previous", "السابق")}:{" "}
                              {prev
                                ? `${Math.max(...prev.sets.map((x) => x.weight))} kg`
                                : t("First session", "الجلسة الأولى")}
                            </p>
                          </div>
                          <button
                            className="icon-button"
                            aria-label="Edit exercise"
                            onClick={() => exerciseForm("active", 0, i)}
                          >
                            <Settings size={17} />
                          </button>
                          <button
                            className="icon-button"
                            aria-label="Remove exercise"
                            onClick={() =>
                              update((d) => {
                                d.active!.exercises.splice(i, 1);
                              })
                            }
                          >
                            <X size={17} />
                          </button>
                        </div>
                        {cues[e.name] && (
                          <p className="exercise-cue">
                            {cues[e.name][ar ? 1 : 0]}
                          </p>
                        )}
                        <div className="set-row labels">
                          <span>{t("SET", "مجموعة")}</span>
                          <span>KG</span>
                          <span>{t("REPS", "تكرار")}</span>
                          <span>{t("DONE", "تم")}</span>
                          <span />
                        </div>
                        {e.sets.map((set, j) => (
                          <div
                            key={j}
                            className={`set-row ${set.done ? "set-done" : ""}`}
                          >
                            <span>{j + 1}</span>
                            <input
                              aria-label={`${e.name} set ${j + 1} weight`}
                              type="number"
                              min="0"
                              max="2000"
                              step="0.5"
                              value={set.weight}
                              onChange={(ev) =>
                                update((d) => {
                                  d.active!.exercises[i].sets[j].weight =
                                    Math.max(
                                      0,
                                      Math.min(2000, +ev.target.value),
                                    );
                                })
                              }
                            />
                            <input
                              aria-label={`${e.name} set ${j + 1} reps`}
                              type="number"
                              min="0"
                              max="1000"
                              value={set.reps}
                              onChange={(ev) =>
                                update((d) => {
                                  d.active!.exercises[i].sets[j].reps =
                                    Math.max(
                                      0,
                                      Math.min(1000, +ev.target.value),
                                    );
                                })
                              }
                            />
                            <button
                              className={`check-button ${set.done ? "checked" : ""}`}
                              aria-label={`Complete set ${j + 1}`}
                              aria-pressed={set.done}
                              onClick={() => {
                                update((d) => {
                                  d.active!.exercises[i].sets[j].done =
                                    !set.done;
                                });
                                if (!set.done) Rest(Date.now() + 90000);
                              }}
                            >
                              <Check size={18} />
                            </button>
                            <button
                              className="icon-button"
                              aria-label="Remove set"
                              onClick={() =>
                                update((d) => {
                                  d.active!.exercises[i].sets.splice(j, 1);
                                })
                              }
                            >
                              <X size={14} />
                            </button>
                          </div>
                        ))}
                        <button
                          className="text-button"
                          onClick={() =>
                            update((d) => {
                              d.active!.exercises[i].sets.push({
                                weight: 0,
                                reps: parseInt(e.reps) || 10,
                                done: false,
                              });
                            })
                          }
                        >
                          <Plus size={15} />
                          {t("Add set", "إضافة مجموعة")}
                        </button>
                        <label className="notes-label">
                          {t("Personal notes", "ملاحظات شخصية")}
                          <textarea
                            value={e.notes}
                            placeholder={t(
                              "How did it feel?",
                              "كيف كان شعورك؟",
                            )}
                            onChange={(ev) =>
                              update((d) => {
                                d.active!.exercises[i].notes = ev.target.value;
                              })
                            }
                          />
                        </label>
                      </section>
                    );
                  })}
                  <div className="actions">
                    <button
                      className="secondary"
                      onClick={() => exerciseForm("active", 0)}
                    >
                      <Plus size={16} />
                      {t("Add exercise", "إضافة تمرين")}
                    </button>
                    <button
                      className="primary"
                      onClick={() => {
                        if (
                          !confirm(
                            t(
                              "Finish and save this session?",
                              "إنهاء وحفظ الجلسة؟",
                            ),
                          )
                        )
                          return;
                        update((d) => {
                          const a = d.active!;
                          a.elapsed = duration(a);
                          a.runningSince = null;
                          a.finished = Date.now();
                          d.sessions.push(a);
                          d.active = null;
                        });
                        Rest(null);
                        P("Progress");
                      }}
                    >
                      <Check size={18} />
                      {t("Finish & save", "إنهاء وحفظ")}
                    </button>
                  </div>
                  <p className="muted">
                    {t(
                      "Cool down with easy movement and gentle stretches. Your session is saved on this device as you go.",
                      "اختتمي بحركة خفيفة وتمدد مريح. تُحفظ جلستك على هذا الجهاز تلقائيًا.",
                    )}
                  </p>
                  <button
                    className="danger text-button"
                    onClick={() => {
                      if (confirm("Discard active workout?"))
                        update((d) => {
                          d.active = null;
                        });
                    }}
                  >
                    {t("Discard session", "إلغاء الجلسة")}
                  </button>
                </>
              ) : (
                <div className="card start-card">
                  <Dumbbell size={40} />
                  <h2>
                    {t("A little stronger starts here.", "القوة تبدأ هنا.")}
                  </h2>
                  <p>
                    {plan.name} · {plan.duration}
                  </p>
                  <button className="primary" onClick={() => start(plan)}>
                    <Play size={16} />
                    {t("Start today’s workout", "بدء تمرين اليوم")}
                  </button>
                  <button
                    className="text-button"
                    onClick={() => P("Workout Plan")}
                  >
                    {t("Choose another workout", "اختيار تمرين آخر")}
                    <ChevronRight size={16} />
                  </button>
                </div>
              )}
            </>
          )}
          {page === "More" && (
            <>
              {heading(
                t("YOUR WELLNESS, TOGETHER", "عافيتك في مكان واحد"),
                t("More for you", "المزيد لك"),
              )}
              <div className="more-grid">
                {[
                  ["Nutrition", Utensils, "Fuel your strength", "التغذية"],
                  ["Classes", Calendar, "Move in good company", "الحصص"],
                  ["Sleep", Moon, "Make room for recovery", "النوم"],
                  ["Settings", Settings, "Make FORME your own", "الإعدادات"],
                  [
                    "Backup",
                    ShieldCheck,
                    "Keep your memories safe",
                    "النسخ الاحتياطي",
                  ],
                ].map(([p, I, desc, a]) => (
                  <button
                    className="card more-card"
                    key={p as string}
                    onClick={() => P(p as string)}
                  >
                    {icon(I)}
                    <div>
                      <h2>{t(p as string, a as string)}</h2>
                      <p>
                        {ar
                          ? (
                              {
                                "Fuel your strength": "غذّي قوتك",
                                "Move in good company": "نوعي حركتك",
                                "Make room for recovery": "امنحي التعافي وقتًا",
                                "Make FORME your own": "اجعلي FORME يناسبك",
                                "Keep your memories safe": "احفظي رحلتك بأمان",
                              } as Record<string, string>
                            )[desc as string]
                          : (desc as string)}
                      </p>
                    </div>
                    <ChevronRight size={18} />
                  </button>
                ))}
              </div>
            </>
          )}
          {page === "Nutrition" && (
            <>
              {heading(
                t("NOURISH, DON’T RESTRICT", "تغذية بلا تقييد"),
                t("Fuel your strength", "غذّي قوتك"),
                t(
                  "Protein, energy, and food you enjoy. No calorie budgets.",
                  "بروتين وطاقة وطعام تستمتعين به.",
                ),
              )}
              <div className="two-col">
                <section className="card">
                  <span className="eyebrow">
                    {t("PROTEIN TODAY", "بروتين اليوم")}
                  </span>
                  <h2 className="big-number">
                    {protein}
                    <small> / {s.profile.protein} g</small>
                  </h2>
                  <div className="bar">
                    <i
                      style={{
                        width: `${Math.min(100, (protein / s.profile.protein) * 100)}%`,
                      }}
                    />
                  </div>
                  <button className="primary" onClick={() => mealForm()}>
                    <Plus size={16} />
                    {t("Log meal", "تسجيل وجبة")}
                  </button>
                </section>
                <section className="card water-card">
                  <span className="eyebrow">
                    {t("HYDRATION TODAY", "ماء اليوم")}
                  </span>
                  <h2 className="big-number">
                    {water}
                    <small> / {s.profile.water} ml</small>
                  </h2>
                  <div className="bar">
                    <i
                      style={{
                        width: `${Math.min(100, (water / s.profile.water) * 100)}%`,
                      }}
                    />
                  </div>
                  <div className="water-buttons">
                    {[150, 250, 500].map((n) => (
                      <button onClick={() => quickWater(n)} key={n}>
                        +{n} ml
                      </button>
                    ))}
                    <button onClick={() => waterForm()}>
                      <Plus size={16} />
                    </button>
                  </div>
                </section>
              </div>
              <div className="section-heading">
                <h2>{t("Meal journal", "سجل الوجبات")}</h2>
              </div>
              {s.meals.length
                ? records("meals", (e) => mealForm(e))
                : empty(
                    t(
                      "Your meals will appear here. Protein estimates come from you.",
                      "ستظهر وجباتك هنا. تقديرات البروتين من إدخالك.",
                    ),
                  )}
              <div className="section-heading">
                <h2>{t("Water journal", "سجل الماء")}</h2>
                <button
                  className="text-button"
                  disabled={!s.water.length}
                  onClick={() =>
                    update((d) => {
                      d.water.pop();
                    })
                  }
                >
                  {t("Undo last", "تراجع عن الأخير")}
                </button>
              </div>
              {s.water.length
                ? records("water", (e) => waterForm(e))
                : empty(
                    t(
                      "Every sip counts. Add your first glass.",
                      "كل رشفة مهمة. أضيفي كوبك الأول.",
                    ),
                  )}
              <div className="section-heading">
                <h2>{t("Your food library", "مكتبة طعامك")}</h2>
                <button className="text-button" onClick={() => foodForm()}>
                  <Plus size={16} />
                  {t("Add food", "إضافة طعام")}
                </button>
              </div>
              <p className="muted">
                {t(
                  "Ideas only. Add protein from a label or your own estimate. Eggs and tuna are excluded.",
                  "أفكار للوجبات. أدخلي البروتين من الملصق أو تقديرك. البيض والتونة مستبعدان.",
                )}
              </p>
              <div className="food-grid">
                {s.foods.map((f, i) =>
                  excluded(f.name) ? null : (
                    <div className="card food" key={i}>
                      <button onClick={() => foodForm(i)}>
                        <span>{f.name}</span>
                        <small>
                          {f.protein === null
                            ? t("Protein not entered", "لم يُدخل البروتين")
                            : `${f.protein} g`}
                        </small>
                      </button>
                      <button
                        className="icon-button"
                        aria-label="Delete food"
                        onClick={() =>
                          update((d) => {
                            d.foods.splice(i, 1);
                          })
                        }
                      >
                        <X size={15} />
                      </button>
                    </div>
                  ),
                )}
              </div>
              <div className="two-col">
                <section className="card guidance">
                  <h2>{t("Around your workout", "حول التمرين")}</h2>
                  <p>
                    {t(
                      "30–60 min before: Banana, dates, or yogurt and fruit.",
                      "قبل ٣٠–٦٠ دقيقة: موز أو تمر أو زبادي وفاكهة.",
                    )}
                  </p>
                  <p>
                    {t(
                      "60–90 min before: Toast with peanut butter and banana.",
                      "قبل ٦٠–٩٠ دقيقة: توست بزبدة الفول السوداني والموز.",
                    )}
                  </p>
                  <p>
                    {t(
                      "After: Chicken and rice, a chicken sandwich, salmon and potatoes, or a Greek yogurt smoothie with protein-rich ingredients.",
                      "بعد التمرين: دجاج وأرز أو شطيرة دجاج أو سلمون وبطاطس أو سموذي زبادي يوناني بمكونات غنية بالبروتين.",
                    )}
                  </p>
                  <p>
                    {t(
                      "Build meals around protein, carbohydrates, vegetables, and hydration.",
                      "اجعلي البروتين والكربوهيدرات والخضار والماء أساس وجباتك.",
                    )}
                  </p>
                </section>
                <section className="card guidance">
                  <h2>
                    {t(
                      "Eat More Often / Limit When Possible",
                      "تناولي أكثر / قللي عندما يمكن",
                    )}
                  </h2>
                  <p>
                    {t(
                      "Prioritize: Protein-rich foods, whole grains, fruits and vegetables, healthy fats, and water.",
                      "أعطي الأولوية للأطعمة الغنية بالبروتين والحبوب الكاملة والفواكه والخضار والدهون الصحية والماء.",
                    )}
                  </p>
                  <p>
                    {t(
                      "Moderate: Sugary drinks, excessive fried foods, highly processed snacks, and excessive caffeine late in the day.",
                      "قللي عند الإمكان المشروبات السكرية والإفراط في المقليات والوجبات شديدة التصنيع والكافيين المتأخر.",
                    )}
                  </p>
                  <p>
                    {t(
                      "Food is nourishment and enjoyment. No food needs a moral label.",
                      "الطعام تغذية ومتعة، ولا يحتاج إلى أحكام أخلاقية.",
                    )}
                  </p>
                </section>
              </div>
            </>
          )}
          {page === "Classes" && (
            <>
              {heading(
                t("FIND YOUR KIND OF MOVEMENT", "اكتشفي حركتك المفضلة"),
                t("A change of pace", "إيقاع مختلف"),
                t(
                  "Schedule classes yourself. Confirm current times with your gym.",
                  "جدولي حصصك يدويًا وتأكدي من أوقاتها مع النادي.",
                ),
              )}
              <div className="section-heading">
                <h2>{t("Your calendar & attendance", "تقويمك وحضورك")}</h2>
                <button className="primary" onClick={() => classForm()}>
                  <Plus size={16} />
                  {t("Add class", "إضافة حصة")}
                </button>
              </div>
              {s.classes.length
                ? records("classes", (e) => classForm(e.name, e))
                : empty(
                    t(
                      "No classes scheduled. Find something you look forward to.",
                      "لم تُجدول أي حصة بعد.",
                    ),
                  )}
              <div className="class-grid">
                {classInfo.map((c) => (
                  <section className="card class-card" key={c[0]}>
                    <span className="eyebrow">
                      {ar
                        ? [
                            "تحمل القوة",
                            "تمارين مائية",
                            "كارديو",
                            "دراجات",
                            "رقص",
                            "كارديو",
                            "تعافٍ",
                            "لياقة بدنية",
                            "متنوع",
                          ][classInfo.indexOf(c)]
                        : c[1]}
                    </span>
                    <h2>{c[0]}</h2>
                    <p>
                      {ar
                        ? [
                            "خيار معدل لتمرين الجسم الكامل. ابدئي بأوزان خفيفة.",
                            "حركة منخفضة التأثير في الماء.",
                            "كارديو مستوحى من الفنون القتالية.",
                            "دراجة داخلية بمقاومة تختارينها.",
                            "رقص إيقاعي للياقة.",
                            "تمارين خطوة للتوازن واللياقة.",
                            "حركة ومرونة وتواصل بين العقل والجسم.",
                            "تمارين مكثفة؛ ليست الخيار الافتراضي للمبتدئات.",
                            "اسألي المدربة عن طبيعة الحصة والتعديلات.",
                          ][classInfo.indexOf(c)]
                        : c[2]}
                    </p>
                    <div className="class-meta">
                      {ar
                        ? [
                            "متوسطة إلى عالية",
                            "منخفضة إلى متوسطة",
                            "عالية",
                            "متوسطة إلى عالية",
                            "متوسطة",
                            "متوسطة إلى عالية",
                            "منخفضة إلى متوسطة",
                            "عالية",
                            "تختلف",
                          ][classInfo.indexOf(c)]
                        : c[3]}{" "}
                      · {c[4]} {t("min", "دقيقة")}
                    </div>
                    <button
                      className="text-button"
                      onClick={() => classForm(c[0])}
                    >
                      {t("Schedule class", "جدولة الحصة")}
                      <Plus size={16} />
                    </button>
                  </section>
                ))}
              </div>
              <div className="notice">
                {t(
                  "Calendar exports are personal reminders, not bookings. Tap the calendar icon on a scheduled class to download an .ics file. No gym integration is used.",
                  "تصدير التقويم تذكير شخصي وليس حجزًا. اضغطي أيقونة التقويم لتنزيل ملف .ics. لا يوجد ربط بالنادي.",
                )}
              </div>
            </>
          )}
          {page === "Sleep" && (
            <>
              {heading(
                t("REST IS PART OF GETTING STRONGER", "الراحة جزء من القوة"),
                t("Your recovery ritual", "طقوس التعافي"),
              )}
              <button className="primary" onClick={() => sleepForm()}>
                <Moon size={17} />
                {t("Log sleep", "تسجيل النوم")}
              </button>
              {s.sleep.length ? (
                <>
                  <div className="notice">
                    {latestSleep.hours < 7 || latestSleep.energy < 3
                      ? t(
                          "Low energy today? Consider lighter weights, a shorter session, or gentle movement. Adjust to how you feel.",
                          "طاقتك منخفضة؟ جربي أوزانًا أخف أو جلسة أقصر أو حركة هادئة، حسب شعورك.",
                        )
                      : t(
                          "Feeling rested? Follow your plan at a comfortable intensity. Keep checking in with yourself.",
                          "تشعرين بالراحة؟ اتبعي خطتك بشدة مريحة واستمعي لجسمك.",
                        )}
                  </div>
                  {records("sleep", (e) => sleepForm(e))}
                </>
              ) : (
                empty(
                  t(
                    "Log bedtime and wake-up to see your recovery patterns.",
                    "سجلي وقت النوم والاستيقاظ لرؤية نمط تعافيك.",
                  ),
                )
              )}
              <Trend kind="sleep" state={s} count={7} ar={ar} />
              <section className="card guidance">
                <h2>{t("A gentler evening", "مساء أكثر هدوءًا")}</h2>
                <p>
                  {t(
                    "Try a consistent wind-down, a comfortable sleep space, and less caffeine late in the day. Recovery is personal; use these as flexible suggestions.",
                    "جربي روتينًا هادئًا ومكان نوم مريحًا وتقليل الكافيين آخر اليوم. التعافي شخصي وهذه اقتراحات مرنة.",
                  )}
                </p>
              </section>
            </>
          )}
          {page === "Progress" && (
            <>
              {heading(
                t("YOUR EFFORT, MADE VISIBLE", "جهدك يظهر"),
                t("Becoming stronger", "تصبحين أقوى"),
                t(
                  "Only your real, saved activity. Every small step belongs here.",
                  "نشاطك الحقيقي المحفوظ فقط. كل خطوة صغيرة لها مكان هنا.",
                ),
              )}
              <div className="segmented">
                {["week", "month"].map((x) => (
                  <button
                    className={period === x ? "selected" : ""}
                    key={x}
                    onClick={() => Period(x)}
                  >
                    {x === "week"
                      ? t("This week", "هذا الأسبوع")
                      : t("This month", "هذا الشهر")}
                  </button>
                ))}
              </div>
              {(() => {
                const since =
                    period === "week" ? weekStart() : `${today.slice(0, 7)}-01`,
                  sessions = s.sessions.filter(
                    (x) => x.date >= since && x.date <= today,
                  ),
                  count =
                    period === "week"
                      ? new Date().getDay() + 1
                      : new Date().getDate(),
                  minutes = Math.round(
                    sessions.reduce((n, x) => n + x.elapsed, 0) / 60000,
                  );
                const prs = new Map<string, number>();
                s.sessions.forEach((x) =>
                  x.exercises.forEach((e) =>
                    e.sets
                      .filter((t) => t.done)
                      .forEach((t) =>
                        prs.set(
                          e.name,
                          Math.max(prs.get(e.name) || 0, t.weight),
                        ),
                      ),
                  ),
                );
                return (
                  <>
                    <div className="stat-grid">
                      {[
                        [sessions.length, t("Workouts", "تمارين")],
                        [`${minutes} min`, t("Training time", "وقت التدريب")],
                        [
                          s.classes.filter(
                            (x) =>
                              x.attended && x.date >= since && x.date <= today,
                          ).length,
                          t("Classes attended", "حصص حضرتها"),
                        ],
                        [
                          `${new Set(sessions.map((x) => x.date)).size} days`,
                          t("Active strength days", "أيام تدريب القوة"),
                        ],
                      ].map(([v, l]) => (
                        <div className="card stat" key={l}>
                          <h2>{v}</h2>
                          <p>{l}</p>
                        </div>
                      ))}
                    </div>
                    <div className="two-col">
                      <Trend kind="workouts" state={s} count={count} ar={ar} />
                      <Trend kind="strength" state={s} count={count} ar={ar} />
                      <Trend kind="protein" state={s} count={count} ar={ar} />
                      <Trend kind="water" state={s} count={count} ar={ar} />
                      <Trend kind="sleep" state={s} count={count} ar={ar} />
                      <section className="card">
                        <h2>{t("Personal records", "الأرقام الشخصية")}</h2>
                        <p>
                          {t(
                            "Highest completed-set load, by exercise.",
                            "أعلى وزن في مجموعة مكتملة، لكل تمرين.",
                          )}
                        </p>
                        {prs.size
                          ? [...prs].map(([name, kg]) => (
                              <div className="record" key={name}>
                                <strong>{name}</strong>
                                <span>{kg} kg</span>
                              </div>
                            ))
                          : empty(
                              t(
                                "Your first completed sets start the story.",
                                "تبدأ القصة بأول مجموعة مكتملة.",
                              ),
                            )}
                      </section>
                    </div>
                  </>
                );
              })()}
              <div className="section-heading">
                <h2>{t("Workout history", "سجل التمارين")}</h2>
              </div>
              {s.sessions.length
                ? s.sessions
                    .slice()
                    .reverse()
                    .map((x) => (
                      <details className="card history" key={x.id}>
                        <summary>
                          <strong>{x.name}</strong>
                          <span>
                            {x.date} · {fmt(x.elapsed)}
                          </span>
                        </summary>
                        {x.exercises.map((e, i) => (
                          <div key={i}>
                            <h3>{e.name}</h3>
                            {e.sets.map((z, j) => (
                              <p key={j}>
                                {j + 1}. {z.weight} kg × {z.reps}{" "}
                                {z.done ? "✓" : ""}{" "}
                                <button
                                  className="text-button"
                                  onClick={() =>
                                    M({
                                      title: t(
                                        "Edit saved set",
                                        "تعديل مجموعة محفوظة",
                                      ),
                                      fields: [
                                        {
                                          key: "weight",
                                          label: t("Weight · kg", "الوزن · كغ"),
                                          type: "number",
                                          min: 0,
                                          max: 2000,
                                          value: z.weight,
                                        },
                                        {
                                          key: "reps",
                                          label: t("Reps", "التكرارات"),
                                          type: "number",
                                          min: 0,
                                          max: 1000,
                                          value: z.reps,
                                        },
                                      ],
                                      onSave: (v) =>
                                        update((d) => {
                                          const set = d.sessions.find(
                                            (a) => a.id === x.id,
                                          )!.exercises[i].sets[j];
                                          set.weight = +v.weight;
                                          set.reps = +v.reps;
                                        }),
                                    })
                                  }
                                >
                                  {t("Edit", "تعديل")}
                                </button>
                              </p>
                            ))}
                            {e.notes && <p>{e.notes}</p>}
                          </div>
                        ))}
                        <button
                          className="text-button danger"
                          onClick={() => remove("sessions", x.id)}
                        >
                          {t("Delete session", "حذف الجلسة")}
                        </button>
                      </details>
                    ))
                : empty(
                    t(
                      "Finish a workout to see your history.",
                      "أكملي تمرينًا لرؤية سجلك.",
                    ),
                  )}
              <div className="section-heading">
                <h2>
                  {t("Body measurements · optional", "قياسات الجسم · اختيارية")}
                </h2>
                <button
                  className="text-button"
                  onClick={() => measurementForm()}
                >
                  <Plus size={16} />
                  {t("Add", "إضافة")}
                </button>
              </div>
              {records("measurements", (e) => measurementForm(e))}
            </>
          )}
          {page === "Settings" && (
            <>
              {heading(
                t("PERSONAL, BY DESIGN", "شخصي، منذ البداية"),
                t("Made for you", "مصمم لك"),
              )}
              <section className="card">
                <form
                  className="settings-form"
                  onSubmit={(e) => {
                    e.preventDefault();
                    const v = Object.fromEntries(new FormData(e.currentTarget));
                    update((d) => {
                      d.profile = {
                        ...d.profile,
                        name: String(v.name),
                        height: +v.height,
                        weight: +v.weight,
                        protein: +v.protein,
                        water: +v.water,
                        frequency: +v.frequency,
                        goal: String(v.goal),
                        workEnd: String(v.workEnd),
                        workoutTime: String(v.workoutTime),
                        exclusions: String(v.exclusions),
                      };
                    });
                    E(
                      t(
                        "Profile saved on this device.",
                        "تم حفظ الملف على هذا الجهاز.",
                      ),
                    );
                  }}
                >
                  {[
                    {
                      key: "name",
                      label: t("Name", "الاسم"),
                      value: s.profile.name,
                    },
                    {
                      key: "height",
                      label: t("Height · cm", "الطول · سم"),
                      type: "number",
                      min: 50,
                      max: 250,
                      value: s.profile.height || "",
                    },
                    {
                      key: "weight",
                      label: t("Starting weight · kg", "وزن البداية · كغ"),
                      type: "number",
                      min: 10,
                      max: 500,
                      value: s.profile.weight || "",
                    },
                    {
                      key: "protein",
                      label: t(
                        "Daily protein goal · g",
                        "هدف البروتين اليومي · غ",
                      ),
                      type: "number",
                      min: 1,
                      max: 500,
                      value: s.profile.protein,
                    },
                    {
                      key: "water",
                      label: t(
                        "Daily water goal · ml",
                        "هدف الماء اليومي · مل",
                      ),
                      type: "number",
                      min: 1,
                      max: 10000,
                      value: s.profile.water,
                    },
                    {
                      key: "frequency",
                      label: t(
                        "Core workouts per week",
                        "التمارين الأساسية أسبوعيًا",
                      ),
                      type: "number",
                      min: 1,
                      max: 7,
                      value: s.profile.frequency,
                    },
                    {
                      key: "workEnd",
                      label: t("Work finishes", "وقت انتهاء العمل"),
                      type: "time",
                      value: s.profile.workEnd,
                    },
                    {
                      key: "workoutTime",
                      label: t("Preferred workout time", "وقت التمرين المفضل"),
                      type: "time",
                      value: s.profile.workoutTime,
                    },
                    {
                      key: "goal",
                      label: t("Your goal", "هدفك"),
                      value: s.profile.goal,
                    },
                    {
                      key: "exclusions",
                      label: t(
                        "Dietary exclusions (eggs and tuna always excluded)",
                        "الأطعمة المستبعدة (البيض والتونة مستبعدان دائمًا)",
                      ),
                      value: s.profile.exclusions,
                    },
                  ].map((f) => (
                    <FieldInput key={f.key} field={f} />
                  ))}
                  <p className="muted">
                    {t(
                      "Sleep schedules can vary. The recovery tracker helps you adjust gently.",
                      "قد تختلف مواعيد النوم. يساعدك سجل التعافي على التكيف بلطف.",
                    )}
                  </p>
                  <button className="primary" type="submit">
                    <Check size={16} />
                    {t("Save profile", "حفظ الملف")}
                  </button>
                </form>
              </section>
              <div className="card guidance">
                <h2>{t("Language", "اللغة")}</h2>
                <button
                  className="secondary"
                  onClick={() =>
                    update((d) => {
                      d.language = ar ? "en" : "ar";
                    })
                  }
                >
                  {ar ? "English" : "العربية"}
                </button>
              </div>
            </>
          )}
          {page === "Backup" && (
            <>
              {heading(
                t("YOUR DATA BELONGS TO YOU", "بياناتك ملكك"),
                t("Keep your story safe", "احفظي رحلتك بأمان"),
              )}
              <section className="card guidance">
                <ShieldCheck size={32} />
                <h2>{t("Private. Local. Yours.", "خاصة. محلية. ملكك.")}</h2>
                <p>
                  {t(
                    "Your profile and health entries stay in IndexedDB on this device. No account, analytics, advertising, or health-data uploads.",
                    "ملفك وسجلاتك الصحية في IndexedDB على هذا الجهاز. بلا حساب أو تحليلات أو إعلانات أو رفع للبيانات الصحية.",
                  )}
                </p>
                <div className="notice">
                  {t(
                    "Local data can be lost if browser storage is cleared, Safari removes website data, or your device is lost. Export backups regularly. A different browser or app address has separate storage.",
                    "قد تفقدين البيانات عند مسح تخزين المتصفح أو إزالة Safari لبيانات الموقع أو فقدان الجهاز. صدّري نسخًا احتياطية بانتظام. لكل متصفح وعنوان موقع تخزين مستقل.",
                  )}
                </div>
                <div className="actions">
                  <button
                    className="primary"
                    onClick={() =>
                      download(
                        JSON.stringify(s, null, 2),
                        `forme-backup-${today}.json`,
                      )
                    }
                  >
                    <Download size={17} />
                    {t("Export JSON backup", "تصدير نسخة JSON")}
                  </button>
                  <button
                    className="secondary"
                    onClick={() => file.current?.click()}
                  >
                    <Upload size={17} />
                    {t("Restore backup", "استعادة نسخة")}
                  </button>
                </div>
                <input
                  ref={file}
                  type="file"
                  accept="application/json,.json"
                  hidden
                  onChange={async (e) => {
                    const f = e.target.files?.[0];
                    e.target.value = "";
                    if (!f) return;
                    try {
                      if (f.size > 20 * 1024 * 1024)
                        throw Error("Backup exceeds 20 MB.");
                      const v = validate(JSON.parse(await f.text()));
                      if (
                        confirm(
                          t(
                            "This will replace ALL existing FORME data on this device. Continue?",
                            "سيستبدل هذا جميع بيانات FORME على هذا الجهاز. متابعة؟",
                          ),
                        )
                      ) {
                        await queue.current;
                        await save(v);
                        latest.current = v;
                        S(v);
                        E(t("Backup restored.", "تمت الاستعادة."));
                      }
                    } catch (err) {
                      E(`Restore failed: ${String(err)}`);
                    }
                  }}
                />
                <p className="muted">
                  {t(
                    "Backups contain personal information. Save them somewhere you trust.",
                    "تحتوي النسخ على معلومات شخصية. احفظيها في مكان تثقين به.",
                  )}
                </p>
                <button
                  className="secondary"
                  onClick={() =>
                    navigator.storage
                      ?.persist?.()
                      .then((v) =>
                        E(
                          v
                            ? "Persistent storage granted. Keep making backups."
                            : "Storage persistence is browser-controlled. Keep making backups.",
                        ),
                      )
                  }
                >
                  {t("Request persistent storage", "طلب تخزين دائم")}
                </button>
              </section>
              <section className="card guidance">
                <h2>{t("Install on your iPhone", "التثبيت على iPhone")}</h2>
                <p>
                  {t(
                    "Open your hosted FORME URL in Safari. Tap Share → Add to Home Screen → Add. Open FORME once online, then it can load offline. Updates require a connection.",
                    "افتحي رابط FORME في Safari. اضغطي مشاركة ← إضافة إلى الشاشة الرئيسية ← إضافة. افتحيه مرة متصلة بالإنترنت ليعمل لاحقًا دون اتصال. التحديثات تحتاج اتصالًا.",
                  )}
                </p>
              </section>
              <section className="card guidance">
                <h2>{t("A fresh start", "بداية جديدة")}</h2>
                <p>
                  {t(
                    "Delete all personal logs, profile edits, and saved plans from this browser.",
                    "حذف جميع السجلات وتعديلات الملف والخطط المحفوظة من هذا المتصفح.",
                  )}
                </p>
                <button
                  className="secondary danger"
                  onClick={async () => {
                    if (
                      confirm(
                        "Delete ALL personal data? This cannot be undone.",
                      ) &&
                      prompt("Type DELETE to confirm") === "DELETE"
                    ) {
                      try {
                        await queue.current;
                        await db.state.clear();
                        const fresh = initial();
                        latest.current = fresh;
                        S(fresh);
                        E(
                          t(
                            "All saved personal data deleted.",
                            "تم حذف جميع البيانات الشخصية المحفوظة.",
                          ),
                        );
                      } catch {
                        E(
                          t(
                            "Deletion failed. Try again.",
                            "فشل الحذف. حاولي مجددًا.",
                          ),
                        );
                      }
                    }
                  }}
                >
                  <Trash2 size={16} />
                  {t("Delete all data", "حذف جميع البيانات")}
                </button>
              </section>
            </>
          )}
        </main>
        <footer>
          FORME <span>—</span>{" "}
          {t("Strength in Your Own Way", "القوة بطريقتك الخاصة")}
          <small>
            {ready
              ? t("Stored privately on your device", "محفوظة بخصوصية على جهازك")
              : ""}
          </small>
        </footer>
      </div>
      <nav className="bottom-nav">
        {["Home", "Workout Plan", "Track", "Progress", "More"].map((p, i) => (
          <button
            key={p}
            className={page === p ? "selected" : ""}
            onClick={() => {
              P(p);
              window.scrollTo(0, 0);
            }}
          >
            {icon([Home, Dumbbell, Plus, ChartNoAxesCombined, Grid2X2][i])}
            <span>
              {t(
                ["Home", "Plan", "Track", "Progress", "More"][i],
                ["الرئيسية", "الخطة", "تسجيل", "التقدم", "المزيد"][i],
              )}
            </span>
          </button>
        ))}
      </nav>
      {!["Home", "Workout Plan", "Track", "Progress", "More"].includes(
        page,
      ) && (
        <button
          className="back-floating"
          aria-label="Back to More"
          onClick={() => P("More")}
        >
          <ArrowLeft size={19} />
        </button>
      )}
      {modal && (
        <div className="modal-backdrop" onClick={() => M(null)}>
          <section
            onKeyDown={(e) => {
              if (e.key === "Tab") {
                const nodes = Array.from(
                  e.currentTarget.querySelectorAll<HTMLElement>(
                    "button,input,select,textarea",
                  ),
                ).filter((x) => !x.hasAttribute("disabled"));
                const first = nodes[0],
                  last = nodes.at(-1);
                if (e.shiftKey && document.activeElement === first) {
                  e.preventDefault();
                  last?.focus();
                } else if (!e.shiftKey && document.activeElement === last) {
                  e.preventDefault();
                  first?.focus();
                }
              }
            }}
            className="modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="modal-title"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="modal-head">
              <h2 id="modal-title">{modal.title}</h2>
              <button
                autoFocus
                className="icon-button"
                aria-label="Close dialog"
                onClick={() => M(null)}
              >
                <X size={22} />
              </button>
            </div>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const v = Object.fromEntries(new FormData(e.currentTarget));
                modal.onSave(v);
                M(null);
              }}
            >
              {modal.fields.map((f) => (
                <FieldInput key={f.key} field={f} />
              ))}
              <datalist id="foods">
                {s.foods.map((f) => (
                  <option key={f.name} value={f.name} />
                ))}
              </datalist>
              <button type="submit" className="primary">
                <Check size={17} />
                {t("Save", "حفظ")}
              </button>
            </form>
          </section>
        </div>
      )}
    </div>
  );
  function foodForm(index?: number) {
    const f = index === undefined ? null : s!.foods[index];
    M({
      title: t("Food library", "مكتبة الطعام"),
      fields: [
        {
          key: "name",
          label: t("Food name", "اسم الطعام"),
          value: f?.name || "",
        },
        {
          key: "protein",
          label: t(
            "Protein · g per your serving (optional)",
            "بروتين · غ للحصة (اختياري)",
          ),
          type: "number",
          min: 0,
          max: 500,
          value: f?.protein ?? "",
          required: false,
        },
      ],
      onSave: (v) => {
        if (excluded(v.name)) {
          E("Eggs and tuna are excluded.");
          return;
        }
        update((d) => {
          const f = {
            name: v.name,
            protein: v.protein === "" ? null : +v.protein,
          };
          if (index === undefined) d.foods.push(f);
          else d.foods[index] = f;
        });
      },
    });
  }
  function measurementForm(e?: Entry) {
    M({
      title: t("Optional measurement", "قياس اختياري"),
      fields: [
        {
          key: "date",
          label: t("Date", "التاريخ"),
          type: "date",
          value: e?.date || today,
        },
        {
          key: "name",
          label: t("Measurement", "القياس"),
          value: e?.name || "Waist",
        },
        {
          key: "value",
          label: t("Value", "القيمة"),
          type: "number",
          min: 0.1,
          max: 1000,
          value: e?.value || "",
        },
        {
          key: "unit",
          label: t("Unit", "الوحدة"),
          options: ["cm", "kg"],
          value: e?.unit || "cm",
        },
      ],
      onSave: (v) => add("measurements", { ...v, value: +v.value }, e?.id),
    });
  }
}
function FieldInput({ field: f }: { field: Field }) {
  return (
    <label className="field">
      {f.label}
      {f.options ? (
        <select name={f.key} defaultValue={f.value || f.options[0]}>
          {f.options.map((o) => (
            <option key={o}>{o}</option>
          ))}
        </select>
      ) : (
        <input
          name={f.key}
          list={f.type === "food" ? "foods" : undefined}
          type={f.type === "food" ? "text" : f.type || "text"}
          defaultValue={f.value ?? ""}
          required={f.required !== false}
          min={f.min}
          max={f.max}
          step={f.type === "number" ? "any" : undefined}
          maxLength={1000}
        />
      )}
    </label>
  );
}
function Trend({
  kind,
  state: s,
  count,
  ar,
}: {
  kind: string;
  state: State;
  count: number;
  ar: boolean;
}) {
  const [chosen, Choose] = useState("");
  const choices = [
    ...new Set(
      s.sessions.flatMap((x) =>
        x.exercises
          .filter((e) => e.sets.some((z) => z.done))
          .map((e) => e.name),
      ),
    ),
  ];
  const selected = choices.includes(chosen) ? chosen : choices[0] || "";
  const from = new Date();
  from.setDate(from.getDate() - (count - 1));
  const names: Record<string, string[]> = {
    water: ["Hydration · ml", "الماء · مل"],
    protein: ["Protein · g", "البروتين · غ"],
    sleep: ["Sleep · hours", "النوم · ساعات"],
    workouts: ["Workout consistency", "الانتظام في التمارين"],
    strength: [
      "Strength · best completed load (kg)",
      "القوة · أعلى وزن مكتمل (كغ)",
    ],
  };
  const data = Array.from({ length: count }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (count - 1 - i));
    const key = dateKey(d);
    let value: number | null = 0;
    if (kind === "water") value = sum(s.water, "ml", key);
    if (kind === "protein") value = sum(s.meals, "protein", key);
    if (kind === "sleep") {
      const logs = s.sleep.filter((x) => x.date === key);
      value = logs.length
        ? logs.reduce((n, x) => n + x.hours, 0) / logs.length
        : null;
    }
    if (kind === "workouts")
      value = s.sessions.filter((x) => x.date === key).length;
    if (kind === "strength") {
      const loads = s.sessions
        .filter((x) => x.date === key)
        .flatMap((x) =>
          x.exercises
            .filter((e) => e.name === selected)
            .flatMap((e) => e.sets.filter((z) => z.done).map((z) => z.weight)),
        );
      value = loads.length ? Math.max(...loads) : null;
    }
    return {
      date: key.slice(5),
      value: value === null ? null : Math.round(value * 10) / 10,
    };
  });
  const source =
    kind === "water"
      ? s.water
      : kind === "protein"
        ? s.meals
        : kind === "sleep"
          ? s.sleep
          : s.sessions;
  const has =
    kind === "strength"
      ? data.some((x) => x.value !== null)
      : source.some((x) => x.date >= dateKey(from) && x.date <= dateKey());
  return (
    <section className="card chart">
      <h2>{names[kind][ar ? 1 : 0]}</h2>
      {kind === "strength" && choices.length > 0 && (
        <label className="field">
          {ar ? "التمرين" : "Exercise"}
          <select value={selected} onChange={(e) => Choose(e.target.value)}>
            {choices.map((x) => (
              <option key={x}>{x}</option>
            ))}
          </select>
        </label>
      )}
      {has ? (
        <ResponsiveContainer width="100%" height={190}>
          {kind === "strength" || kind === "sleep" ? (
            <LineChart data={data}>
              <CartesianGrid vertical={false} stroke="#ffffff0a" />
              <XAxis
                dataKey="date"
                tick={{ fill: "#aaa3ad", fontSize: 10 }}
                axisLine={false}
                tickLine={false}
                minTickGap={20}
              />
              <Tooltip
                contentStyle={{
                  background: "#222129",
                  border: "1px solid #4a3c45",
                  borderRadius: 12,
                }}
              />
              <Line
                dataKey="value"
                stroke={kind === "sleep" ? "#8DAEC7" : "#A97990"}
                strokeWidth={2}
                dot={{ r: 3 }}
              />
            </LineChart>
          ) : (
            <BarChart data={data}>
              <CartesianGrid vertical={false} stroke="#ffffff0a" />
              <XAxis
                dataKey="date"
                tick={{ fill: "#aaa3ad", fontSize: 10 }}
                axisLine={false}
                tickLine={false}
                minTickGap={20}
              />
              <Tooltip
                contentStyle={{
                  background: "#222129",
                  border: "1px solid #4a3c45",
                  borderRadius: 12,
                }}
              />
              <Bar
                dataKey="value"
                fill={kind === "water" ? "#8DAEC7" : "#A97990"}
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          )}
        </ResponsiveContainer>
      ) : (
        <div className="empty">
          <ChartNoAxesCombined size={25} />
          <p>
            {ar
              ? "ستظهر اتجاهاتك هنا بعد التسجيل."
              : "Your trends will appear here as you log."}
          </p>
        </div>
      )}
    </section>
  );
}
createRoot(document.getElementById("root")!).render(<App />);
if ("serviceWorker" in navigator)
  window.addEventListener("load", () =>
    navigator.serviceWorker
      .register(`${import.meta.env.BASE_URL}sw.js`)
      .catch(() => window.dispatchEvent(new Event("forme-offline-error"))),
  );
