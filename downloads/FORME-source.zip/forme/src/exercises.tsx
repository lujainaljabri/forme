import React from "react";
export const cues: Record<string, [string, string]> = {
  "Leg Press": [
    "Sit supported. Press the platform away, then lower with control; keep knees comfortably aligned.",
    "اجلسي مع دعم الظهر. ادفعي المنصة ثم اخفضيها بتحكم مع محاذاة مريحة للركبتين.",
  ],
  "Hip Thrust": [
    "Support your upper back on a bench. Drive through your feet and lift your hips, keeping ribs relaxed.",
    "اسندي أعلى ظهرك على مقعد. ادفعي بالقدمين وارفعي الوركين مع إرخاء الأضلاع.",
  ],
  "Romanian Deadlift": [
    "Soften your knees, hinge your hips back, and keep the load close. Stand by driving through your feet.",
    "اثني الركبتين قليلًا وأرجعي الوركين مع إبقاء الوزن قريبًا ثم قفي بالدفع بالقدمين.",
  ],
  "Leg Curl": [
    "Align the machine with your knees. Curl your heels toward you, then return slowly.",
    "حاذي الجهاز مع الركبتين. اثني الساقين نحوك ثم عودي ببطء.",
  ],
  "Lat Pulldown": [
    "Sit tall. Pull the bar toward your upper chest with elbows down, then extend slowly.",
    "اجلسي باستقامة واسحبي البار نحو أعلى الصدر بالمرفقين للأسفل ثم مدي ببطء.",
  ],
  "Seated Row": [
    "Sit tall and pull handles toward your ribs. Keep shoulders relaxed and return with control.",
    "اجلسي باستقامة واسحبي المقابض نحو الأضلاع مع استرخاء الكتفين ثم عودي بتحكم.",
  ],
  "Cable Row": [
    "Keep your torso steady. Draw elbows back toward the ribs, then release slowly.",
    "ثبتي الجذع واسحبي المرفقين للخلف نحو الأضلاع ثم عودي ببطء.",
  ],
  "Chest Press": [
    "Set handles near chest height. Press forward with a supported back, then lower with control.",
    "اضبطي المقابض عند الصدر واضغطي للأمام مع دعم الظهر ثم عودي بتحكم.",
  ],
  "Shoulder Press": [
    "Start at shoulder height. Press overhead in a comfortable range without arching your back.",
    "ابدئي عند الكتفين واضغطي فوق الرأس ضمن مدى مريح دون تقويس الظهر.",
  ],
  "Goblet Squat": [
    "Hold a weight at your chest. Sit down between your hips, then push through your feet to stand.",
    "احملي الوزن عند الصدر وانزلي بين الوركين ثم ادفعي بالقدمين للوقوف.",
  ],
  "Glute Bridge": [
    "Lie on your back with feet planted. Lift hips into a comfortable line, pause, then lower.",
    "استلقي على ظهرك مع تثبيت القدمين وارفعي الوركين بخط مريح ثم توقفي واخفضي.",
  ],
  "Dead Bug": [
    "Lie on your back, arms up. Slowly extend opposite arm and leg, keeping your trunk steady. Alternate sides.",
    "استلقي وارفعي الذراعين. مدي ذراعًا والساق المقابلة ببطء مع ثبات الجذع وبدلي الجانبين.",
  ],
};
export function ExerciseArt({ name }: { name: string }) {
  let body =
      "M32 23L32 39M32 27L20 21L15 28M32 27L44 21L49 28M32 39L23 54M32 39L41 54",
    head = [32, 14],
    equipment = "M8 57H56";
  if (/Leg Press/.test(name)) {
    head = [16, 24];
    body = "M18 31L25 40L37 31L47 33M25 40L37 40L47 33";
    equipment = "M10 20L18 44H30M49 23L49 43M8 56H56";
  } else if (/Hip Thrust|Glute Bridge/.test(name)) {
    head = [12, 36];
    body = "M18 38L32 29L44 38L50 52M32 29L40 42L36 53M24 33L29 40";
    equipment = /Hip/.test(name)
      ? "M5 43H23M10 43V54M22 43V54M26 27H40"
      : "M6 55H56";
  } else if (/Dead Bug/.test(name)) {
    head = [13, 45];
    body =
      "M19 45L37 45M24 45L27 29L37 24M28 45L18 31M37 45L42 32L52 32M37 45L49 51";
    equipment = "M7 56H57";
  } else if (/Squat/.test(name)) {
    head = [31, 13];
    body = "M31 21L30 35L17 40L16 53M30 35L44 41L48 53M31 25L23 29L30 29L37 25";
    equipment = "M26 23H36M29 20V28M7 56H56";
  } else if (/Deadlift/.test(name)) {
    head = [40, 19];
    body = "M36 24L26 35L27 44L22 54M26 35L37 45L39 54M35 25L44 40";
    equipment = "M37 42H52M39 38V46M50 38V46M7 57H57";
  } else if (/Leg Curl/.test(name)) {
    head = [18, 16];
    body = "M18 24L23 37L38 37L43 48M23 37L34 43L31 53M20 27L32 32";
    equipment = "M12 30V44H36M17 44V55M35 44V55M40 49H49";
  } else if (/Pulldown/.test(name)) {
    head = [31, 22];
    body =
      "M31 30V41L42 45L43 54M31 41L22 47L19 54M31 32L20 29L16 17M31 32L43 29L48 17";
    equipment = "M11 16H53M31 7V16M22 43H40M25 43V56";
  } else if (/Row/.test(name)) {
    head = [25, 19];
    body = "M25 26L26 40L42 41L49 52M26 40L17 46L14 53M25 29L38 32L43 30";
    equipment = "M45 30H59M58 15V54M17 44H33M20 44V55";
  } else if (/Chest Press/.test(name)) {
    head = [22, 17];
    body = "M22 25V40L37 43L40 54M22 29L35 29L42 25M22 40L19 52";
    equipment = "M14 20V44H32M15 44V55M42 19V32M40 25H48";
  } else if (/Shoulder Press/.test(name)) {
    head = [31, 23];
    body =
      "M31 31V43L42 46L45 54M31 43L21 48L18 54M31 32L19 25V14M31 32L43 25V14";
    equipment = "M14 13H24M38 13H48M23 45H39M28 45V56";
  }
  return (
    <svg
      className="exercise-art"
      viewBox="0 0 64 64"
      role="img"
      aria-label={`${name} movement illustration`}
    >
      <circle cx={head[0]} cy={head[1]} r="4.5" fill="currentColor" />
      <g
        stroke="currentColor"
        strokeWidth="2.8"
        fill="none"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d={body} />
        <path opacity=".4" d={equipment} />
      </g>
    </svg>
  );
}
