// @vitest-environment jsdom
import "fake-indexeddb/auto";
import React from "react";
import { it, expect, vi } from "vitest";
import { screen, waitFor, fireEvent, within } from "@testing-library/react";
import { db } from "./data";
it("runs end-to-end logs, active workout, saved history, and Arabic layout", async () => {
  document.body.innerHTML = '<div id="root"></div>';
  vi.stubGlobal(
    "ResizeObserver",
    class {
      observe() {}
      unobserve() {}
      disconnect() {}
    },
  );
  vi.spyOn(window, "confirm").mockReturnValue(true);
  await import("./main");
  await screen.findByText("Welcome to FORME 🤍");
  fireEvent.click(screen.getByRole("button", { name: "Open profile" }));
  fireEvent.change(screen.getByLabelText("Name"), {
    target: { value: "Alex" },
  });
  fireEvent.change(screen.getByLabelText("Height · cm"), {
    target: { value: "160" },
  });
  fireEvent.change(screen.getByLabelText("Starting weight · kg"), {
    target: { value: "60" },
  });
  fireEvent.submit(
    screen.getByRole("button", { name: "Save profile" }).closest("form")!,
  );
  fireEvent.click(screen.getAllByRole("button", { name: "Home" })[0]);
  await screen.findByText("Welcome back, Alex 🤍");
  expect(screen.queryByText("42.5")).toBeNull();
  fireEvent.click(screen.getByRole("button", { name: "+ 250 ml" }));
  await waitFor(async () =>
    expect((await db.state.get("main"))!.value.water[0].ml).toBe(250),
  );
  fireEvent.click(screen.getByRole("button", { name: "Log meal" }));
  let dialog = screen.getByRole("dialog");
  fireEvent.change(
    within(dialog).getByLabelText("Food · choose or enter your own"),
    { target: { value: "Chicken with rice" } },
  );
  fireEvent.change(
    within(dialog).getByLabelText("Estimated protein · g (your input)"),
    { target: { value: "30" } },
  );
  fireEvent.submit(
    within(dialog).getByRole("button", { name: "Save" }).closest("form")!,
  );
  await waitFor(async () =>
    expect((await db.state.get("main"))!.value.meals[0].protein).toBe(30),
  );
  fireEvent.click(screen.getByRole("button", { name: "Add class" }));
  dialog = screen.getByRole("dialog");
  fireEvent.change(within(dialog).getByLabelText("Class"), {
    target: { value: "Aqua" },
  });
  fireEvent.change(
    within(dialog).getByLabelText("Replace this day’s planned workout?"),
    { target: { value: "Yes" } },
  );
  fireEvent.submit(
    within(dialog).getByRole("button", { name: "Save" }).closest("form")!,
  );
  await waitFor(async () => {
    const v = (await db.state.get("main"))!.value;
    expect(v.classes[0].name).toBe("Aqua");
    expect(v.classes[0].replace).toBe("Yes");
    expect(v.plans[0].name).toBe("Lower body");
  });
  fireEvent.click(screen.getByRole("button", { name: "Log sleep" }));
  dialog = screen.getByRole("dialog");
  fireEvent.change(within(dialog).getByLabelText("Bedtime"), {
    target: { value: "2026-11-13T23:00" },
  });
  fireEvent.change(within(dialog).getByLabelText("Wake-up"), {
    target: { value: "2026-11-14T07:00" },
  });
  fireEvent.submit(
    within(dialog).getByRole("button", { name: "Save" }).closest("form")!,
  );
  await waitFor(async () =>
    expect((await db.state.get("main"))!.value.sleep[0].hours).toBe(8),
  );
  fireEvent.click(screen.getAllByRole("button", { name: "Workout Plan" })[0]);
  fireEvent.click(
    screen.getAllByRole("button", { name: "Edit / reschedule" })[0],
  );
  dialog = screen.getByRole("dialog");
  fireEvent.change(within(dialog).getByLabelText("Day · swaps schedules"), {
    target: { value: "Monday" },
  });
  fireEvent.submit(
    within(dialog).getByRole("button", { name: "Save" }).closest("form")!,
  );
  await waitFor(async () => {
    const plans = (await db.state.get("main"))!.value.plans;
    expect(plans[0].name).toBe("Rest");
    expect(plans[1].name).toBe("Lower body");
  });
  fireEvent.click(
    screen.getAllByRole("button", { name: "Edit / reschedule" })[1],
  );
  dialog = screen.getByRole("dialog");
  fireEvent.change(within(dialog).getByLabelText("Day · swaps schedules"), {
    target: { value: "Sunday" },
  });
  fireEvent.submit(
    within(dialog).getByRole("button", { name: "Save" }).closest("form")!,
  );
  await waitFor(async () =>
    expect((await db.state.get("main"))!.value.plans[0].name).toBe(
      "Lower body",
    ),
  );
  fireEvent.click(screen.getAllByRole("button", { name: "Start session" })[0]);
  await screen.findByText("SESSION IN PROGRESS");
  const weight = screen.getByLabelText("Leg Press set 1 weight");
  fireEvent.change(weight, { target: { value: "25" } });
  fireEvent.click(screen.getAllByRole("button", { name: "Complete set 1" })[0]);
  await waitFor(async () =>
    expect(
      (await db.state.get("main"))!.value.active!.exercises[0].sets[0],
    ).toEqual({ weight: 25, reps: 10, done: true }),
  );
  fireEvent.click(screen.getByRole("button", { name: "Finish & save" }));
  await screen.findByText("Becoming stronger");
  await waitFor(async () => {
    const state = (await db.state.get("main"))!.value;
    expect(state.active).toBeNull();
    expect(state.sessions).toHaveLength(1);
    expect(state.sessions[0].exercises[0].sets[0].weight).toBe(25);
  });
  fireEvent.click(screen.getAllByRole("button", { name: "More" })[0]);
  fireEvent.click(
    screen.getByRole("button", { name: /Backup Keep your memories safe/ }),
  );
  const restored = structuredClone((await db.state.get("main"))!.value);
  restored.profile.name = "Alex restored";
  const input = document.querySelector<HTMLInputElement>("input[type=file]")!;
  fireEvent.change(input, {
    target: {
      files: [
        { size: 100, text: () => Promise.resolve(JSON.stringify(restored)) },
      ],
    },
  });
  await waitFor(async () =>
    expect((await db.state.get("main"))!.value.profile.name).toBe(
      "Alex restored",
    ),
  );
  expect((await db.state.get("main"))!.value.sessions).toHaveLength(1);
  fireEvent.click(screen.getAllByRole("button", { name: "Progress" })[0]);
  fireEvent.click(screen.getByRole("button", { name: "العربية" }));
  await screen.findByText("تصبحين أقوى");
  expect(document.querySelector(".app")?.getAttribute("dir")).toBe("rtl");
  await waitFor(async () =>
    expect((await db.state.get("main"))!.value.language).toBe("ar"),
  );
});
