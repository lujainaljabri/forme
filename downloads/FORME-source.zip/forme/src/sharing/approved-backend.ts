// Public connection details only; permissions require authenticated server checks.
// This does not save a connection, sign in, enable sharing, or upload fitness data.
import type { Connection } from "./model";
export const approvedBackend: Connection = {
  url: "https://bgobhswgfxydjdyaxcwe.supabase.co",
  key: "sb_publishable_MQl98t6aPhFhDEtfBKpUHA_b2fgWP0t",
};
