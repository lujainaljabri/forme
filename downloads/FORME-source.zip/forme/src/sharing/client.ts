import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import {
  connection,
  approvedScopes,
  type Connection,
  type Scope,
  type Projection,
} from "./model";
const CONFIG = "forme-sharing-connection-v1";
const VIEWER_CONFIG = "forme-viewer-connection-v1";
export const SYNC = "forme-sharing-approved-sync-v1";
let cached: { key: string; client: SupabaseClient } | null = null;
export function savedConnection(): Connection | null {
  try {
    const v = localStorage.getItem(CONFIG);
    return v ? connection(JSON.parse(v)) : null;
  } catch {
    return null;
  }
}
export function saveConnection(v: Connection) {
  stopLocalSync();
  localStorage.setItem(CONFIG, JSON.stringify(connection(v)));
}
export function forgetConnection() {
  stopLocalSync();
  localStorage.removeItem(CONFIG);
}
export function savedViewerConnection(): Connection | null {
  try {
    const raw = localStorage.getItem(VIEWER_CONFIG);
    return raw ? connection(JSON.parse(raw)) : null;
  } catch {
    return null;
  }
}
export function saveViewerConnection(v: Connection) {
  localStorage.setItem(VIEWER_CONFIG, JSON.stringify(connection(v)));
}
export function approveSync(config: Connection, userId: string, scopes: Scope) {
  localStorage.setItem(SYNC, JSON.stringify({ config, userId, scopes }));
}
export function consentScopes(
  config: Connection,
  userId: string,
  server: Scope,
): Scope | null {
  try {
    return approvedScopes(
      JSON.parse(localStorage.getItem(SYNC) || "null"),
      config,
      userId,
      server,
    );
  } catch {
    return null;
  }
}
export function hasSyncConsent() {
  return localStorage.getItem(SYNC) !== null;
}
export function clientFor(v: Connection) {
  const safe = connection(v),
    key = JSON.stringify(safe);
  if (cached?.key === key) return cached.client;
  const client = createClient(safe.url, safe.key, {
    auth: {
      flowType: "pkce",
      storageKey: `forme-sharing-auth-${new URL(safe.url).hostname}`,
      persistSession: true,
      detectSessionInUrl: true,
    },
    global: {
      fetch: (input, init) =>
        fetch(input, {
          ...init,
          cache: "no-store",
          referrerPolicy: "no-referrer",
        }),
    },
  });
  cached = { key, client };
  return client;
}
export async function rpc<T>(
  client: SupabaseClient,
  name: string,
  args?: Record<string, unknown>,
): Promise<T> {
  const { data, error } = await client.rpc(name, args);
  if (error) throw Error(error.message);
  return data as T;
}
export type OwnerStatus = Scope & {
  enabled: boolean;
  viewerJoined: boolean;
  targetGithubId: string | null;
  updatedAt: string | null;
};
export async function upload(client: SupabaseClient, p: Projection) {
  return rpc<void>(client, "forme_publish", {
    p_schedule: p.schedule,
    p_completed: p.completed,
    p_charts: p.charts,
  });
}
export async function login(client: SupabaseClient, viewer = false) {
  const redirectTo =
    location.origin + location.pathname + (viewer ? "?view=1" : "?sharing=1");
  const { error } = await client.auth.signInWithOAuth({
    provider: "github",
    options: { redirectTo, scopes: "read:user" },
  });
  if (error) throw Error(error.message);
}
export function stopLocalSync() {
  localStorage.removeItem(SYNC);
}
