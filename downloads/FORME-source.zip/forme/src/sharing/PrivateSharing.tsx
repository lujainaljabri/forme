import { approvedBackend } from "./approved-backend";
import React, { useState, useEffect, useRef } from "react";
import {
  ShieldCheck,
  Eye,
  Lock,
  Link,
  RefreshCw,
  UserRound,
  LogOut,
} from "lucide-react";
import type { State } from "../data";
import {
  noScopes,
  project,
  connection,
  invitationLink,
  randomToken,
  type Scope,
  type Connection,
} from "./model";
import {
  savedConnection,
  saveConnection,
  forgetConnection,
  clientFor,
  login,
  rpc,
  upload,
  approveSync,
  consentScopes,
  hasSyncConsent,
  stopLocalSync,
  type OwnerStatus,
} from "./client";
export function SharingSync({ state }: { state: State }) {
  const latest = useRef(state);
  latest.current = state;
  useEffect(() => {
    let cancelled = false,
      busy = false;
    async function sync() {
      if (busy || !hasSyncConsent()) return;
      const c = savedConnection();
      if (!c) return;
      busy = true;
      try {
        const client = clientFor(c);
        const { data } = await client.auth.getSession();
        if (!data.session) return;
        const status = await rpc<OwnerStatus>(client, "forme_owner_status");
        if (cancelled) return;
        if (!status.enabled) {
          stopLocalSync();
          return;
        }
        const allowed = consentScopes(c, data.session.user.id, status);
        if (!allowed) return;
        await upload(client, project(latest.current, allowed));
        window.dispatchEvent(new Event("forme-share-synced"));
      } catch {
        window.dispatchEvent(new Event("forme-share-sync-error"));
      } finally {
        busy = false;
      }
    }
    const timer = setInterval(sync, 30000);
    const onVisible = () => {
      if (document.visibilityState === "visible") void sync();
    };
    document.addEventListener("visibilitychange", onVisible);
    void sync();
    return () => {
      cancelled = true;
      clearInterval(timer);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, []);
  return null;
}
export default function PrivateSharing({ state }: { state: State }) {
  const ar = state.language === "ar",
    t = (en: string, arText: string) => (ar ? arText : en);
  const [config, C] = useState<Connection | null>(() => savedConnection()),
    [role, Role] = useState(""),
    [authId, AuthId] = useState(""),
    [status, Status] = useState<OwnerStatus | null>(null),
    [scopes, Scopes] = useState<Scope>(noScopes),
    [busy, B] = useState(false),
    [notice, Notice] = useState(""),
    [invite, Invite] = useState(""),
    [preview, Preview] = useState(false);
  const client = config ? clientFor(config) : null;
  async function refresh(resetDraft = true) {
    if (!client) return;
    const { data, error } = await client.auth.getSession();
    if (error) throw error;
    if (!data.session) {
      Role("signed-out");
      Status(null);
      return;
    }
    AuthId(data.session.user.id);
    const r = await rpc<string>(client, "forme_role");
    Role(r);
    if (r === "owner") {
      const s = await rpc<OwnerStatus>(client, "forme_owner_status");
      Status(s);
      if (resetDraft)
        Scopes({
          schedule: s.schedule,
          completed: s.completed,
          charts: s.charts,
        });
    }
  }
  async function run(fn: () => Promise<void>) {
    B(true);
    Notice("");
    try {
      await fn();
    } catch (e) {
      Notice(
        `${t("Not completed", "لم تكتمل العملية")}: ${e instanceof Error ? e.message : String(e)}`,
      );
    } finally {
      B(false);
    }
  }
  useEffect(() => {
    if (!client) return;
    void run(refresh);
    const { data } = client.auth.onAuthStateChange(() => {
      setTimeout(() => void run(refresh), 0);
    });
    const synced = () => void run(() => refresh(false));
    window.addEventListener("forme-share-synced", synced);
    return () => {
      data.subscription.unsubscribe();
      window.removeEventListener("forme-share-synced", synced);
    };
  }, [client]);
  const selections = [
    [
      "schedule",
      t("Workout schedule", "جدول التمارين"),
      t(
        "Days, times, exercises, target sets and reps. No notes or loads.",
        "الأيام والأوقات والتمارين والمجموعات والتكرارات المستهدفة، بلا ملاحظات أو أوزان.",
      ),
    ],
    [
      "completed",
      t("Completed workouts", "التمارين المكتملة"),
      t(
        "Last 100 sessions: date, title, minutes, and completed sets.",
        "آخر ١٠٠ جلسة: التاريخ والعنوان والدقائق والمجموعات المكتملة.",
      ),
    ],
    [
      "charts",
      t("Activity progress charts", "رسوم تقدم النشاط"),
      t(
        "28 days of workout counts, training minutes, and completed sets only.",
        "٢٨ يومًا من عدد التمارين ودقائق التدريب والمجموعات المكتملة فقط.",
      ),
    ],
  ] as const;
  const sample = project(state, scopes);
  return (
    <>
      <div className="page-heading">
        <span className="eyebrow">
          {t("FOR ONE TRUSTED PERSON", "لشخص واحد تثقين به")}
        </span>
        <h1>{t("Private Sharing", "المشاركة الخاصة")}</h1>
        <p>
          {t(
            "You stay the only Owner. Your trusted Viewer can only read what you choose.",
            "تبقين المالكة الوحيدة. يشاهد الشخص الموثوق ما تختارينه فقط.",
          )}
        </p>
      </div>
      <div className="sharing-status card">
        <ShieldCheck size={26} />
        <div>
          <strong>
            {status?.enabled
              ? t("Sharing enabled", "المشاركة مفعلة")
              : config && !status
                ? t("Live status not verified", "لم يتم التحقق من الحالة")
                : t("Sharing is off", "المشاركة متوقفة")}
          </strong>
          <p>
            {status?.enabled
              ? t(
                  "Only approved sections can be read by your accepted Viewer.",
                  "يشاهد المشاهد المقبول الأقسام المصرح بها فقط.",
                )
              : config && !status
                ? t(
                    "Backend status must be verified online. Do not assume access has been revoked.",
                    "يجب التحقق من حالة الخادم عبر الإنترنت. لا تفترضي إلغاء الوصول.",
                  )
                : t(
                    "No fitness data is uploaded while sharing is off. Your full history stays in IndexedDB.",
                    "لا تُرفع بيانات اللياقة أثناء إيقاف المشاركة. يبقى سجلك الكامل في IndexedDB.",
                  )}
          </p>
        </div>
        <span className="pill">{t("OWNER CONTROL", "تحكم المالكة")}</span>
      </div>
      {notice && (
        <div className="notice" role="status">
          {notice}
        </div>
      )}
      <div className="two-col">
        <section className="card guidance">
          <Lock size={23} />
          <h2>{t("A snapshot or a live view?", "نسخة ثابتة أم عرض مباشر؟")}</h2>
          <p>
            {t(
              "A manually sent snapshot is a fixed copy. It can be free and encrypted, but a downloaded copy cannot be revoked.",
              "النسخة اليدوية ثابتة. يمكن أن تكون مجانية ومشفرة، لكن لا يمكن سحب نسخة تم تنزيلها.",
            )}
          </p>
          <p>
            {t(
              "Live sharing uses authentication and backend permissions. Access can be revoked for future reads. It refreshes while your Owner app is open; the Viewer sees the last successful sync.",
              "المشاركة المباشرة تستخدم تسجيل الدخول وصلاحيات الخادم. يمكن إلغاء القراءات المستقبلية. تتحدث البيانات عندما يكون تطبيق المالكة مفتوحًا ويظهر آخر تحديث ناجح.",
            )}
          </p>
          <small>
            {t(
              "Previously seen information and screenshots cannot be recalled.",
              "لا يمكن استرجاع معلومات شوهدت أو صور شاشة التقطت سابقًا.",
            )}
          </small>
        </section>
        <section className="card guidance">
          <Eye size={23} />
          <h2>{t("Hidden, always", "مخفية دائمًا")}</h2>
          <p>
            {t(
              "Nutrition, hydration, body weight and measurements, sleep, profile details, private notes, active workouts, and exercise loads are excluded from this feature.",
              "التغذية والماء والوزن والقياسات والنوم والملف والملاحظات الخاصة والتمرين الجاري وأوزان التمارين مستبعدة من هذه الميزة.",
            )}
          </p>
          <p>
            {t(
              "The Viewer never receives an admin role or permission to change your fitness data.",
              "لا يحصل المشاهد على دور إداري أو صلاحية لتغيير بيانات لياقتك.",
            )}
          </p>
        </section>
      </div>
      {!config ? (
        <section className="card guidance">
          <h2>
            {t(
              "Optional free backend · not activated",
              "خادم اختياري مجاني · غير مفعل",
            )}
          </h2>
          <p>
            {t(
              "Live sharing is not configured on this device. Setup requires your approval. This screen does not create cloud projects, upload fitness records, or send invitations. Review the setup plan before proceeding.",
              "المشاركة المباشرة غير معدة على هذا الجهاز. يحتاج الإعداد إلى موافقتك. هذه الشاشة لا تنشئ مشاريع سحابية أو ترفع سجلات لياقة أو ترسل دعوات. راجعي الخطة قبل المتابعة.",
            )}
          </p>
          <a
            className="text-button"
            href="./downloads/FORME-private-sharing-guide.md"
            target="_blank"
            rel="noreferrer"
          >
            {t(
              "Read the architecture & safe setup plan",
              "قراءة البنية وخطة الإعداد الآمن",
            )}{" "}
            ↗
          </a>
          <ConnectionForm
            t={t}
            initial={approvedBackend}
            onSave={(v) => {
              saveConnection(v);
              C(v);
              Notice(
                t(
                  "Connection saved. Sign-in alone does not upload fitness records.",
                  "تم حفظ الاتصال. تسجيل الدخول وحده لا يرفع سجلات اللياقة.",
                ),
              );
            }}
          />
        </section>
      ) : (
        <section className="card guidance">
          <h2>{t("Private Sharing identity", "هوية المشاركة الخاصة")}</h2>
          <p>{config.url}</p>
          {role === "signed-out" ? (
            <button
              disabled={busy}
              className="primary"
              onClick={() => void run(() => login(client!))}
            >
              <UserRound size={16} />
              {t("Sign in with GitHub", "الدخول باستخدام GitHub")}
            </button>
          ) : (
            <div className="actions">
              <span className="eyebrow">
                {role === "owner"
                  ? t("SOLE OWNER", "المالكة الوحيدة")
                  : role === "viewer"
                    ? t("READ-ONLY VIEWER", "مشاهد للقراءة فقط")
                    : t("NO OWNER PERMISSION", "بلا صلاحية مالكة")}
              </span>
              <button
                disabled={busy}
                className="secondary"
                onClick={() =>
                  void run(async () => {
                    stopLocalSync();
                    const { error } = await client!.auth.signOut();
                    if (error) throw error;
                    Invite("");
                    Status(null);
                    Role("signed-out");
                  })
                }
              >
                <LogOut size={16} />
                {t("Sign out", "تسجيل الخروج")}
              </button>
            </div>
          )}
          <button
            className="text-button"
            disabled={busy}
            onClick={() => {
              if (
                !confirm(
                  t(
                    "Changing this device’s connection stops local sync but does not revoke any existing backend access. Revoke first if needed. Continue?",
                    "تغيير اتصال هذا الجهاز يوقف المزامنة المحلية لكنه لا يلغي وصول الخادم السابق. ألغيه أولًا عند الحاجة. متابعة؟",
                  ),
                )
              )
                return;
              forgetConnection();
              C(null);
              Status(null);
              Role("");
              Invite("");
            }}
          >
            {t(
              "Change connection on this device",
              "تغيير الاتصال على هذا الجهاز",
            )}
          </button>
          {role === "unassigned" && (
            <div className="notice">
              <p>
                {t(
                  "The backend has not assigned this account as Owner. Only your project administrator can bind the one Owner UUID; there is no self-promotion button.",
                  "لم يُعين هذا الحساب كمالكة. لا يمكن ربط معرف المالكة الوحيدة إلا من إدارة المشروع ولا يوجد زر لترقية النفس.",
                )}
              </p>
              <small>
                {t("Your Auth user ID:", "معرف حسابك:")} <code>{authId}</code>
              </small>
            </div>
          )}
          {role === "viewer" && (
            <a className="text-button" href="?view=1">
              {t(
                "Open read-only Viewer Dashboard",
                "فتح لوحة المشاهد للقراءة فقط",
              )}{" "}
              ↗
            </a>
          )}
        </section>
      )}
      {(role === "owner" || !config) && (
        <>
          <section className="card guidance">
            <h2>
              {t("Choose exactly what is visible", "اختاري بدقة ما يظهر")}
            </h2>
            <p>
              {t(
                "All choices start off. Selection changes are a draft until you apply them. Review workout titles too: any text in a chosen title will be visible.",
                "تبدأ جميع الخيارات متوقفة. التغييرات مسودة حتى تطبيقها. راجعي عناوين التمارين أيضًا؛ سيظهر النص في العنوان المختار.",
              )}
            </p>
            {selections.map(([key, name, description]) => (
              <label key={key} className="share-choice">
                <input
                  type="checkbox"
                  checked={scopes[key]}
                  disabled={busy}
                  onChange={(e) =>
                    Scopes((v) => ({ ...v, [key]: e.target.checked }))
                  }
                />
                <span>
                  <strong>{name}</strong>
                  <small>{description}</small>
                </span>
              </label>
            ))}
            <button className="text-button" onClick={() => Preview(!preview)}>
              <Eye size={16} />
              {preview
                ? t("Hide exact preview", "إخفاء المعاينة الدقيقة")
                : t(
                    "Preview exact shared fields",
                    "معاينة الحقول المشاركة بدقة",
                  )}
            </button>
            {preview && (
              <pre className="share-preview">
                {JSON.stringify(sample, null, 2)}
              </pre>
            )}
            <div className="actions">
              <button
                disabled={
                  busy ||
                  role !== "owner" ||
                  !Object.values(scopes).some(Boolean)
                }
                className="primary"
                onClick={() =>
                  void run(async () => {
                    if (
                      !confirm(
                        t(
                          "Approve uploading ONLY the previewed selections to this Supabase project and enabling read-only access for your accepted Viewer?",
                          "الموافقة على رفع الخيارات المعروضة فقط إلى هذا المشروع وتفعيل الوصول للمشاهد المقبول؟",
                        ),
                      )
                    )
                      return;
                    await rpc(client!, "forme_configure", {
                      p_enabled: true,
                      p_schedule: scopes.schedule,
                      p_completed: scopes.completed,
                      p_charts: scopes.charts,
                    });
                    await refresh(false);
                    await upload(client!, sample);
                    approveSync(config!, authId, scopes);
                    await refresh();
                    Notice(
                      t(
                        "Sharing enabled. Selected-only sync runs every 30 seconds while this app is open.",
                        "تم تفعيل المشاركة. تتحدث البيانات المختارة كل ٣٠ ثانية عندما يكون التطبيق مفتوحًا.",
                      ),
                    );
                  })
                }
              >
                {status?.enabled
                  ? t("Apply permissions & sync", "تطبيق الصلاحيات والمزامنة")
                  : t(
                      "Approve & enable selected sharing",
                      "الموافقة وتفعيل المشاركة المختارة",
                    )}
              </button>
              {status?.enabled && (
                <button
                  disabled={busy}
                  className="secondary"
                  onClick={() =>
                    void run(async () => {
                      stopLocalSync();
                      await rpc(client!, "forme_configure", {
                        p_enabled: false,
                        p_schedule: scopes.schedule,
                        p_completed: scopes.completed,
                        p_charts: scopes.charts,
                      });
                      Invite("");
                      await refresh();
                      Notice(
                        t(
                          "Sharing disabled on the backend. Stored summary removed.",
                          "تم إيقاف المشاركة في الخادم وحذف الملخص المخزن.",
                        ),
                      );
                    })
                  }
                >
                  {t("Disable sharing", "إيقاف المشاركة")}
                </button>
              )}
            </div>
          </section>
          {role === "owner" && (
            <section className="card guidance">
              <h2>{t("One trusted Viewer", "مشاهد واحد موثوق")}</h2>
              <p>
                {status?.viewerJoined
                  ? t(
                      "Your invitation has been accepted. Only that authenticated Viewer can read the approved summary.",
                      "قُبلت الدعوة. لا يقرأ الملخص المصرح به إلا هذا المشاهد بعد تسجيل الدخول.",
                    )
                  : t(
                      "Invite one GitHub account. This adds no repository collaborator and no project administrator.",
                      "ادعي حساب GitHub واحدًا. لا يُضاف متعاون للمستودع أو مدير للمشروع.",
                    )}
              </p>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  const username = String(
                    new FormData(e.currentTarget).get("username"),
                  ).trim();
                  void run(async () => {
                    if (!/^[a-zA-Z0-9][a-zA-Z0-9-]{0,38}$/.test(username))
                      throw Error("Enter a valid GitHub username.");
                    const res = await fetch(
                      `https://api.github.com/users/${encodeURIComponent(username)}`,
                      { cache: "no-store", referrerPolicy: "no-referrer" },
                    );
                    if (!res.ok)
                      throw Error("GitHub account could not be verified.");
                    const user = await res.json();
                    if (!Number.isSafeInteger(user.id) || user.type !== "User")
                      throw Error("Choose a personal GitHub account.");
                    if (
                      !confirm(
                        t(
                          `Invite @${user.login} as your only read-only Viewer? This replaces any previous Viewer.`,
                          `دعوة @${user.login} كمشاهد وحيد للقراءة فقط؟ سيتم استبدال أي مشاهد سابق.`,
                        ),
                      )
                    )
                      return;
                    const token = randomToken();
                    await rpc(client!, "forme_invite", {
                      p_github_id: String(user.id),
                      p_token: token,
                    });
                    Invite(invitationLink(config!, token));
                    await refresh();
                    Notice(
                      t(
                        "Invitation created for that verified GitHub identity. It expires in 24 hours and works once. Send it yourself to your trusted person.",
                        "أُنشئت دعوة لهوية GitHub المحددة. تنتهي خلال ٢٤ ساعة وتستخدم مرة واحدة. أرسليها بنفسك للشخص الموثوق.",
                      ),
                    );
                  });
                }}
              >
                <label className="field">
                  {t(
                    "Trusted person’s GitHub username",
                    "اسم مستخدم GitHub للشخص الموثوق",
                  )}
                  <input
                    name="username"
                    required
                    autoComplete="off"
                    placeholder="github-username"
                  />
                </label>
                <button className="primary" disabled={busy || !status?.enabled}>
                  <Link size={16} />
                  {t("Create private invitation", "إنشاء دعوة خاصة")}
                </button>
              </form>
              {invite && (
                <>
                  <label className="field">
                    {t("Invitation · keep private", "الدعوة · احتفظي بها خاصة")}
                    <textarea readOnly value={invite} />
                  </label>
                  <button
                    className="secondary"
                    onClick={() =>
                      void run(async () => {
                        await navigator.clipboard.writeText(invite);
                        Notice(
                          t(
                            "Invitation copied. Send it only to your trusted person.",
                            "تم نسخ الدعوة. أرسليها فقط للشخص الموثوق.",
                          ),
                        );
                      })
                    }
                  >
                    {t("Copy invitation", "نسخ الدعوة")}
                  </button>
                </>
              )}
              {status?.updatedAt && (
                <p>
                  {t("Last successful upload:", "آخر رفع ناجح:")}{" "}
                  {new Date(status.updatedAt).toLocaleString()}
                </p>
              )}
              <div className="actions">
                <button
                  disabled={busy || !status?.enabled}
                  className="secondary"
                  onClick={() =>
                    void run(async () => {
                      const current = await rpc<OwnerStatus>(
                        client!,
                        "forme_owner_status",
                      );
                      if (!current.enabled) throw Error("Sharing is off.");
                      const allowed = consentScopes(config!, authId, current);
                      if (!allowed)
                        throw Error(
                          "Approve the selected permissions on this device before syncing.",
                        );
                      await upload(client!, project(state, allowed));
                      await refresh();
                      Notice(
                        t(
                          "Selected summary synced.",
                          "تمت مزامنة الملخص المختار.",
                        ),
                      );
                    })
                  }
                >
                  <RefreshCw size={15} />
                  {t("Sync now", "مزامنة الآن")}
                </button>
                <button
                  disabled={busy}
                  className="secondary danger"
                  onClick={() =>
                    void run(async () => {
                      if (
                        !confirm(
                          t(
                            "Revoke the Viewer and any pending invitation?",
                            "إلغاء وصول المشاهد وأي دعوة معلقة؟",
                          ),
                        )
                      )
                        return;
                      stopLocalSync();
                      await rpc(client!, "forme_revoke");
                      Invite("");
                      await refresh();
                      Notice(
                        t(
                          "Access revoked. Viewer binding, invitation, and stored summary removed.",
                          "أُلغي الوصول وحُذفت هوية المشاهد والدعوة والملخص المخزن.",
                        ),
                      );
                    })
                  }
                >
                  {t(
                    "Revoke access & delete shared copy",
                    "إلغاء الوصول وحذف النسخة المشاركة",
                  )}
                </button>
              </div>
              <small>
                {t(
                  "Revocation needs an internet connection. If a request fails, the last backend permissions remain in effect until a successful retry.",
                  "إلغاء الوصول يحتاج اتصالًا بالإنترنت. إذا فشل الطلب تبقى آخر صلاحيات الخادم حتى نجاح المحاولة مجددًا.",
                )}
              </small>
            </section>
          )}
        </>
      )}
    </>
  );
}
export function ConnectionForm({
  t,
  onSave,
  initial,
}: {
  t: (en: string, ar: string) => string;
  onSave: (v: Connection) => void;
  initial?: Connection;
}) {
  const [error, E] = useState("");
  return (
    <form
      className="sharing-connection"
      onSubmit={(e) => {
        e.preventDefault();
        const f = new FormData(e.currentTarget);
        try {
          onSave(
            connection({
              url: String(f.get("url")),
              key: String(f.get("key")),
            }),
          );
          E("");
        } catch (e) {
          E(String(e));
        }
      }}
    >
      <label className="field">
        {t(
          "Approved Supabase HTTPS project URL",
          "عنوان مشروع Supabase المعتمد HTTPS",
        )}
        <input
          name="url"
          defaultValue={initial?.url || ""}
          type="url"
          required
          placeholder="https://your-project.supabase.co"
        />
      </label>
      <label className="field">
        {t("Publishable / anon key only", "مفتاح publishable / anon فقط")}
        <input
          name="key"
          defaultValue={initial?.key || ""}
          required
          autoComplete="off"
          placeholder="sb_publishable_…"
        />
      </label>
      <p>
        {t(
          "Only connect after approving the free backend setup. Never paste a service-role key, secret key, database password, or GitHub OAuth secret here.",
          "اتصلي فقط بعد الموافقة على إعداد الخادم المجاني. لا تلصقي مفتاح service-role أو مفتاحًا سريًا أو كلمة مرور قاعدة البيانات أو سر OAuth هنا.",
        )}
      </p>
      {error && <p role="alert">{error}</p>}
      <button className="secondary" type="submit">
        {t("Save approved connection", "حفظ الاتصال المعتمد")}
      </button>
    </form>
  );
}
