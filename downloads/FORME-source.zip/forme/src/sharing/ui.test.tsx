// @vitest-environment jsdom
import React from "react";
import { afterEach, it, expect, vi } from "vitest";
import { render, screen, fireEvent, cleanup } from "@testing-library/react";
import { initial } from "../data";
import PrivateSharing, { SharingSync } from "./PrivateSharing";
afterEach(() => {
  cleanup();
  localStorage.clear();
  vi.unstubAllGlobals();
});
it("starts disabled, previews only explicit fields, and sends no requests without approval", () => {
  const fetcher = vi.fn();
  vi.stubGlobal("fetch", fetcher);
  const s = initial();
  s.profile.name = "PRIVATE PROFILE";
  s.plans[0].notes = "PRIVATE NOTES";
  const before = JSON.stringify(s);
  render(
    <>
      <SharingSync state={s} />
      <PrivateSharing state={s} />
    </>,
  );
  expect(screen.getByText("Sharing is off")).toBeTruthy();
  const checkboxes = screen.getAllByRole("checkbox") as HTMLInputElement[];
  expect(checkboxes).toHaveLength(3);
  expect(checkboxes.every((x) => !x.checked)).toBe(true);
  expect(
    (
      screen.getByRole("button", {
        name: "Approve & enable selected sharing",
      }) as HTMLButtonElement
    ).disabled,
  ).toBe(true);
  fireEvent.click(checkboxes[0]);
  fireEvent.click(
    screen.getByRole("button", { name: "Preview exact shared fields" }),
  );
  expect(document.querySelector("pre")!.textContent).toContain("Lower body");
  expect(document.querySelector("pre")!.textContent).not.toMatch(
    /PRIVATE|weight|notes|profile/,
  );
  expect(JSON.stringify(s)).toBe(before);
  expect(fetcher).not.toHaveBeenCalled();
});
it("retains RTL and private-first defaults in Arabic", () => {
  const s = initial();
  s.language = "ar";
  render(<PrivateSharing state={s} />);
  expect(screen.getByText("المشاركة متوقفة")).toBeTruthy();
  expect(
    (screen.getAllByRole("checkbox") as HTMLInputElement[]).every(
      (x) => !x.checked,
    ),
  ).toBe(true);
});
