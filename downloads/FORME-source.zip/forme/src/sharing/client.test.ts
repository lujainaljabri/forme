// @vitest-environment jsdom
import { it, expect, afterEach } from "vitest";
import {
  saveConnection,
  savedConnection,
  saveViewerConnection,
  savedViewerConnection,
  approveSync,
  consentScopes,
  hasSyncConsent,
} from "./client";
const owner = {
    url: "https://ownerproject.supabase.co",
    key: "sb_publishable_owner-public-key-long-enough",
  },
  other = {
    url: "https://viewerproject.supabase.co",
    key: "sb_publishable_viewer-public-key-long-enough",
  },
  scope = { schedule: true, completed: false, charts: false };
afterEach(() => localStorage.clear());
it("isolates Viewer connection settings from the Owner project and upload consent", () => {
  saveConnection(owner);
  approveSync(owner, "owner-id", scope);
  saveViewerConnection(other);
  expect(savedConnection()).toEqual(owner);
  expect(savedViewerConnection()).toEqual(other);
  expect(consentScopes(owner, "owner-id", scope)).toEqual(scope);
  expect(consentScopes(other, "owner-id", scope)).toBeNull();
  expect(consentScopes(owner, "viewer-id", scope)).toBeNull();
});
it("requires new consent whenever Owner connection settings change", () => {
  saveConnection(owner);
  expect(hasSyncConsent()).toBe(false);
  approveSync(owner, "owner-id", scope);
  expect(hasSyncConsent()).toBe(true);
  saveConnection(other);
  expect(hasSyncConsent()).toBe(false);
});
