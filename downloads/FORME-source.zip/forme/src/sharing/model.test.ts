import { describe, it, expect } from "vitest";
import { initial, type State } from "../data";
import {
  project,
  noScopes,
  connection,
  approvedScopes,
  type Scope,
} from "./model";
const config = {
  url: "https://testproject.supabase.co",
  key: "sb_publishable_public-test-key-long-enough",
};
function privateFixture(): State {
  const s = initial();
  s.profile.name = "PRIVATE PROFILE";
  s.profile.weight = 77.7;
  s.plans[0].notes = "PRIVATE PLAN NOTE";
  s.plans[0].exercises[0].notes = "PRIVATE EXERCISE NOTE";
  s.plans[0].exercises[0].sets[0].weight = 987;
  s.meals.push({
    id: "1",
    date: "2026-11-14",
    name: "PRIVATE FOOD",
    protein: 88,
  });
  s.sleep.push({
    id: "2",
    date: "2026-11-14",
    hours: 9,
    notes: "PRIVATE SLEEP",
  });
  s.water.push({ id: "3", date: "2026-11-14", ml: 900 });
  s.measurements.push({
    id: "4",
    date: "2026-11-14",
    name: "PRIVATE MEASUREMENT",
    value: 77.7,
  });
  s.sessions.push({
    id: "private-id",
    name: "Training A",
    date: "2026-11-14",
    started: 1000,
    finished: 1801000,
    elapsed: 1800000,
    runningSince: null,
    exercises: structuredClone(s.plans[0].exercises),
  });
  s.sessions[0].exercises[0].sets[0].done = true;
  s.active = { ...s.sessions[0], name: "PRIVATE ACTIVE", finished: undefined };
  return s;
}
describe("strict sharing projection", () => {
  it("shares nothing by default", () =>
    expect(project(privateFixture(), noScopes)).toEqual({
      schedule: null,
      completed: null,
      charts: null,
    }));
  it("strips private categories, notes, weights and identifiers for every scope combination", () => {
    const s = privateFixture(),
      before = JSON.stringify(s);
    for (let mask = 0; mask < 8; mask++) {
      const scope = {
        schedule: !!(mask & 1),
        completed: !!(mask & 2),
        charts: !!(mask & 4),
      };
      const out = project(s, scope, new Date(2026, 10, 14));
      const json = JSON.stringify(out);
      expect(json).not.toMatch(
        /PRIVATE|987|77\.7|private-id|protein|weight|notes|profile|sleep|water|measurements/,
      );
      for (const key of Object.keys(scope) as (keyof Scope)[])
        expect(out[key] !== null).toBe(scope[key]);
    }
    expect(JSON.stringify(s)).toBe(before);
  });
  it("derives charts from saved completed sessions only, without wellness metrics", () => {
    const s = privateFixture();
    s.sessions.push({ ...s.active!, date: "2026-11-14" });
    const p = project(
      s,
      { schedule: false, completed: true, charts: true },
      new Date(2026, 10, 14),
    );
    expect(p.charts).toHaveLength(28);
    expect(p.charts!.at(-1)).toEqual({
      date: "2026-11-14",
      workouts: 1,
      minutes: 30,
      completedSets: 1,
    });
    expect(p.completed).toEqual([
      { date: "2026-11-14", name: "Training A", minutes: 30, completedSets: 1 },
    ]);
  });
  it("rejects secret keys and arbitrary network destinations", () => {
    expect(connection(config)).toEqual(config);
    for (const url of [
      "http://testproject.supabase.co",
      "https://evil.example",
      "https://testproject.supabase.co/path",
      "https://testproject.supabase.co/?x=1",
      "https://u:p@testproject.supabase.co",
    ])
      expect(() => connection({ ...config, url })).toThrow();
    expect(() =>
      connection({ ...config, key: "sb_secret_do-not-use" }),
    ).toThrow();
    const roleKey = (role: string) =>
      `e30.${btoa(JSON.stringify({ role }))}.sig`;
    expect(() =>
      connection({ ...config, key: roleKey("service_role") }),
    ).toThrow();
    expect(() => connection({ ...config, key: roleKey("anon") })).not.toThrow();
  });
  it("binds upload consent to the exact project and Owner identity; backend cannot broaden local consent", () => {
    const approval = {
      config,
      userId: "owner",
      scopes: { schedule: true, completed: false, charts: false },
    };
    expect(
      approvedScopes(approval, config, "owner", {
        schedule: true,
        completed: true,
        charts: true,
      }),
    ).toEqual({ schedule: true, completed: false, charts: false });
    expect(
      approvedScopes(
        approval,
        { ...config, url: "https://other.supabase.co" },
        "owner",
        noScopes,
      ),
    ).toBeNull();
    expect(approvedScopes(approval, config, "viewer", noScopes)).toBeNull();
    expect(approvedScopes(null, config, "owner", noScopes)).toBeNull();
    expect(approvedScopes("yes", config, "owner", noScopes)).toBeNull();
  });
});
