import { dateKey, type State } from "../data";
export type Scope = { schedule: boolean; completed: boolean; charts: boolean };
export const noScopes: Scope = {
  schedule: false,
  completed: false,
  charts: false,
};
export type SharedSchedule = {
  day: number;
  name: string;
  time: string;
  duration: string;
  exercises: { name: string; sets: number; reps: string }[];
};
export type SharedWorkout = {
  date: string;
  name: string;
  minutes: number;
  completedSets: number;
};
export type SharedChart = {
  date: string;
  workouts: number;
  minutes: number;
  completedSets: number;
};
export type Projection = {
  schedule: SharedSchedule[] | null;
  completed: SharedWorkout[] | null;
  charts: SharedChart[] | null;
};
export type ViewerData = Projection & { updatedAt: string };
// Construct every field explicitly. Never spread a private record into a shared object.
// Exercise loads and all other wellness metrics are intentionally excluded.
export function project(
  state: State,
  scope: Scope,
  at = new Date(),
): Projection {
  const workouts = state.sessions
    .filter((x) => Number.isFinite(x.finished))
    .map((x) => ({
      date: x.date,
      name: x.name.slice(0, 120),
      minutes: Math.round(x.elapsed / 60000),
      completedSets: x.exercises.reduce(
        (n, e) => n + e.sets.filter((z) => z.done).length,
        0,
      ),
    }));
  const completed = workouts
    .slice()
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, 100);
  return {
    schedule: scope.schedule
      ? state.plans.map((p) => ({
          day: p.day,
          name: p.name.slice(0, 120),
          time: p.time,
          duration: p.duration.slice(0, 40),
          exercises: p.exercises.slice(0, 30).map((e) => ({
            name: e.name.slice(0, 120),
            sets: e.sets.length,
            reps: e.reps.slice(0, 30),
          })),
        }))
      : null,
    completed: scope.completed ? completed : null,
    charts: scope.charts
      ? Array.from({ length: 28 }, (_, i) => {
          const d = new Date(at);
          d.setDate(d.getDate() - (27 - i));
          const date = dateKey(d),
            rows = workouts.filter((x) => x.date === date);
          return {
            date,
            workouts: rows.length,
            minutes: rows.reduce((n, x) => n + x.minutes, 0),
            completedSets: rows.reduce((n, x) => n + x.completedSets, 0),
          };
        })
      : null,
  };
}
export type Connection = { url: string; key: string };
export function connection(raw: Connection): Connection {
  const u = new URL(raw.url);
  if (!/^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/.test(u.href))
    throw Error("Use your HTTPS Supabase project URL.");
  const key = raw.key.trim();
  let anon = false;
  if (key.startsWith("sb_publishable_") && key.length > 25) anon = true;
  else
    try {
      const claims = JSON.parse(
        atob(key.split(".")[1].replace(/-/g, "+").replace(/_/g, "/")),
      );
      anon = claims.role === "anon";
    } catch {
      /* invalid public key */
    }
  if (!anon)
    throw Error(
      "Only a publishable/anon key is allowed. Never enter a secret or service-role key.",
    );
  return { url: u.origin, key };
}
export const randomToken = () =>
  Array.from(crypto.getRandomValues(new Uint8Array(32)), (n) =>
    n.toString(16).padStart(2, "0"),
  ).join("");
export function invitationLink(config: Connection, token: string) {
  const u = new URL(location.origin + location.pathname);
  u.searchParams.set("view", "1");
  u.hash = new URLSearchParams({
    project: config.url,
    key: config.key,
    invite: token,
  }).toString();
  return u.href;
}
export function readInvitation(
  hash = location.hash,
): { config: Connection; token: string } | null {
  const p = new URLSearchParams(hash.slice(1));
  if (!p.has("invite")) return null;
  const token = p.get("invite") || "";
  if (!/^[a-f0-9]{64}$/.test(token))
    throw Error("Invalid invitation. Ask the Owner for a new one.");
  return {
    config: connection({
      url: p.get("project") || "",
      key: p.get("key") || "",
    }),
    token,
  };
}
export type SyncApproval = {
  config: Connection;
  userId: string;
  scopes: Scope;
};
export function approvedScopes(
  raw: unknown,
  config: Connection,
  userId: string,
  server: Scope,
): Scope | null {
  const a = raw as SyncApproval;
  if (
    !a ||
    !a.config ||
    a.userId !== userId ||
    a.config.url !== config.url ||
    a.config.key !== config.key ||
    !a.scopes ||
    ["schedule", "completed", "charts"].some(
      (k) => typeof a.scopes[k as keyof Scope] !== "boolean",
    )
  )
    return null;
  return {
    schedule: server.schedule && a.scopes.schedule,
    completed: server.completed && a.scopes.completed,
    charts: server.charts && a.scopes.charts,
  };
}
