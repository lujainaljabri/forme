// @vitest-environment jsdom
import { it, expect, vi } from "vitest";
import { screen } from "@testing-library/react";
import { db } from "../data";
it("the real Viewer URL never mounts the Owner app or reads Owner IndexedDB", async () => {
  history.replaceState(null, "", "/?view=1");
  localStorage.clear();
  sessionStorage.clear();
  document.body.innerHTML = '<div id="root"></div>';
  const read = vi.spyOn(db.state, "get");
  const network = vi.fn();
  vi.stubGlobal("fetch", network);
  await import("../main");
  await screen.findByText("Your invitation starts here");
  expect(read).not.toHaveBeenCalled();
  expect(screen.queryByText("Welcome to FORME 🤍")).toBeNull();
  expect(screen.queryByRole("button", { name: "Start workout" })).toBeNull();
  expect(network).not.toHaveBeenCalled();
  read.mockRestore();
  vi.unstubAllGlobals();
});
