// @vitest-environment jsdom
import React from "react";
import { it, expect, vi, beforeEach, afterEach } from "vitest";
import {
  render,
  screen,
  waitFor,
  fireEvent,
  cleanup,
} from "@testing-library/react";
import { db } from "../data";
const mocks = vi.hoisted(() => ({
  rpc: vi.fn(),
  getSession: vi.fn(),
  signOut: vi.fn(),
  unsubscribe: vi.fn(),
}));
vi.mock("./client", () => ({
  savedViewerConnection: () => ({
    url: "https://test.supabase.co",
    key: "sb_publishable_test-public-key-long-enough",
  }),
  saveViewerConnection: vi.fn(),
  clientFor: () => ({
    auth: {
      getSession: mocks.getSession,
      onAuthStateChange: () => ({
        data: { subscription: { unsubscribe: mocks.unsubscribe } },
      }),
      signOut: mocks.signOut,
    },
  }),
  rpc: mocks.rpc,
  login: vi.fn(),
}));
import Viewer from "./Viewer";
beforeEach(() => {
  vi.clearAllMocks();
  sessionStorage.clear();
  history.replaceState(null, "", "/?view=1");
  Object.defineProperty(document, "visibilityState", {
    configurable: true,
    value: "visible",
  });
  mocks.getSession.mockResolvedValue({
    data: { session: { user: { id: "viewer" } } },
  });
  mocks.signOut.mockResolvedValue({ error: null });
});
afterEach(() => cleanup());
it("renders a read-only dashboard without reading local Owner data and fails closed after revocation", async () => {
  const localRead = vi.spyOn(db.state, "get");
  mocks.rpc.mockResolvedValue({
    schedule: null,
    charts: null,
    completed: [
      {
        name: "Shared training",
        date: "2026-11-14",
        minutes: 45,
        completedSets: 8,
      },
    ],
    updatedAt: "2026-11-14T12:00:00Z",
  });
  render(<Viewer />);
  await screen.findByText("Shared training");
  expect(localRead).not.toHaveBeenCalled();
  expect(
    screen.queryByRole("button", {
      name: /save|delete|approve|invite|start workout/i,
    }),
  ).toBeNull();
  expect(screen.queryByText("Weekly rhythm")).toBeNull();
  expect(document.querySelectorAll("input,textarea")).toHaveLength(0);
  mocks.rpc.mockRejectedValue(Error("No active Viewer permission"));
  fireEvent.click(screen.getByRole("button", { name: "Verify & refresh" }));
  await waitFor(() => expect(screen.queryByText("Shared training")).toBeNull());
  expect(screen.getByText(/Shared information is unavailable/)).toBeTruthy();
  expect(localRead).not.toHaveBeenCalled();
  localRead.mockRestore();
});
it("does not read shared data when an invitation fails its backend identity check", async () => {
  sessionStorage.setItem("forme-pending-invitation", "a".repeat(64));
  mocks.rpc.mockRejectedValue(Error("Invitation unavailable"));
  render(<Viewer />);
  await screen.findByText(/Shared information is unavailable/);
  expect(mocks.rpc.mock.calls.some((x) => x[1] === "forme_claim")).toBe(true);
  expect(mocks.rpc.mock.calls.some((x) => x[1] === "forme_view")).toBe(false);
});
