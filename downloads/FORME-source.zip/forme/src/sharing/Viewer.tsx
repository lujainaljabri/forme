import React, { useEffect, useState } from "react";
import { Eye, ShieldCheck, Dumbbell, RefreshCw, LogOut } from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  Tooltip,
  CartesianGrid,
} from "recharts";
import { readInvitation, type Connection, type ViewerData } from "./model";
import {
  savedViewerConnection,
  saveViewerConnection,
  clientFor,
  rpc,
  login,
} from "./client";
import { ConnectionForm } from "./PrivateSharing";
const PENDING = "forme-pending-invitation";
const pageVisible = () => document.visibilityState !== "hidden";
const connected = () => navigator.onLine !== false;
// Isolated entry point: never loads the Owner App component or reads the fitness database.
export default function Viewer() {
  const [config, C] = useState<Connection | null>(() =>
      savedViewerConnection(),
    ),
    [auth, Auth] = useState(false),
    [data, D] = useState<ViewerData | null>(null),
    [error, E] = useState(""),
    [busy, B] = useState(false),
    [language, L] = useState("en");
  const ar = language === "ar",
    t = (en: string, arabic: string) => (ar ? arabic : en);
  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = ar ? "rtl" : "ltr";
  }, [language]);
  useEffect(() => {
    try {
      const invitation = readInvitation();
      if (invitation) {
        saveViewerConnection(invitation.config);
        sessionStorage.setItem(PENDING, invitation.token);
        history.replaceState(null, "", location.pathname + "?view=1");
        C(invitation.config);
      }
    } catch (e) {
      E(String(e));
    }
  }, []);
  useEffect(() => {
    if (!config) return;
    let cancelled = false,
      inflight = false;
    const client = clientFor(config);
    async function refresh() {
      if (inflight || !pageVisible() || !connected()) return;
      inflight = true;
      try {
        const { data: session, error } = await client.auth.getSession();
        if (error) throw error;
        if (cancelled) return;
        Auth(!!session.session);
        if (!session.session) {
          D(null);
          return;
        }
        const token = sessionStorage.getItem(PENDING);
        if (token) {
          await rpc(client, "forme_claim", { p_token: token });
          sessionStorage.removeItem(PENDING);
        }
        const next = await rpc<ViewerData | null>(client, "forme_view");
        if (!cancelled && pageVisible() && connected()) {
          D(next);
          E(
            next
              ? ""
              : t(
                  "No shared summary yet. The Owner may need to sync.",
                  "لا يوجد ملخص مشارك بعد. قد تحتاج المالكة للمزامنة.",
                ),
          );
        }
      } catch (e) {
        if (!cancelled) {
          D(null);
          E(
            t(
              "Shared information is unavailable. Access may be disabled or revoked, the invitation may not match this GitHub account, or your connection may be offline.",
              "المعلومات غير متاحة. قد يكون الوصول متوقفًا أو ملغى أو الحساب غير مطابق للدعوة أو الاتصال منقطعًا.",
            ),
          );
        }
      } finally {
        inflight = false;
        if (!cancelled) B(false);
      }
    }
    B(true);
    void refresh();
    const timer = setInterval(refresh, 15000);
    const focus = () => void refresh();
    const visible = () => {
      if (document.visibilityState === "hidden") D(null);
      else void refresh();
    };
    const offline = () => {
      D(null);
      E(
        t(
          "Reconnect to verify your Viewer permission.",
          "اتصلي بالإنترنت للتحقق من صلاحية المشاهدة.",
        ),
      );
    };
    const { data: listener } = client.auth.onAuthStateChange(() =>
      setTimeout(refresh, 0),
    );
    window.addEventListener("focus", focus);
    document.addEventListener("visibilitychange", visible);
    window.addEventListener("offline", offline);
    window.addEventListener("forme-view-refresh", focus);
    return () => {
      cancelled = true;
      clearInterval(timer);
      listener.subscription.unsubscribe();
      window.removeEventListener("focus", focus);
      document.removeEventListener("visibilitychange", visible);
      window.removeEventListener("offline", offline);
      window.removeEventListener("forme-view-refresh", focus);
    };
  }, [config, language]);
  const days = ar
    ? ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"]
    : [
        "Sunday",
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
      ];
  return (
    <div className="viewer-shell" dir={ar ? "rtl" : "ltr"}>
      <header>
        <span className="wordmark">FORME</span>
        <button className="language" onClick={() => L(ar ? "en" : "ar")}>
          {ar ? "EN" : "العربية"}
        </button>
      </header>
      <main>
        <div className="page-heading">
          <span className="eyebrow">
            {t("A PRIVATE WINDOW INTO PROGRESS", "نافذة خاصة على التقدم")}
          </span>
          <h1>{t("Strength, witnessed.", "القوة، بنظرة داعمة.")}</h1>
          <p>
            {t(
              "A little encouragement. A shared journey. Only what the Owner chooses.",
              "قليل من التشجيع ورحلة مشتركة، وفقط ما تختاره المالكة.",
            )}
          </p>
        </div>
        <div className="sharing-status card">
          <Eye size={24} />
          <div>
            <strong>
              {t("Viewer Dashboard · read only", "لوحة المشاهد · للقراءة فقط")}
            </strong>
            <p>
              {t(
                "You cannot edit fitness data, change permissions, or become an administrator.",
                "لا يمكنك تعديل بيانات اللياقة أو الصلاحيات أو التحول إلى مدير.",
              )}
            </p>
          </div>
          <ShieldCheck size={21} />
        </div>
        {!config && (
          <section className="card guidance">
            <h2>{t("Your invitation starts here", "دعوتك تبدأ هنا")}</h2>
            <p>
              {t(
                "Open the private invitation sent by the Owner. The link contains no fitness data. A verified GitHub sign-in is required to accept it.",
                "افتحي الدعوة الخاصة المرسلة من المالكة. الرابط لا يحتوي بيانات لياقة. يلزم تسجيل دخول GitHub الموثق لقبولها.",
              )}
            </p>
            <ConnectionForm
              t={t}
              onSave={(v) => {
                saveViewerConnection(v);
                C(v);
              }}
            />
          </section>
        )}
        {error && (
          <div className="notice" role="status">
            {error}
          </div>
        )}
        {config && !auth && (
          <section className="card start-card">
            <ShieldCheck size={35} />
            <h2>{t("Just for the invited person", "للشخص المدعو فقط")}</h2>
            <p>
              {t(
                "Sign in to the exact GitHub account the Owner invited. The invitation alone grants no access.",
                "سجلي الدخول إلى حساب GitHub الذي دعته المالكة تحديدًا. الدعوة وحدها لا تمنح الوصول.",
              )}
            </p>
            <button
              className="primary"
              disabled={busy}
              onClick={() => {
                B(true);
                void login(clientFor(config), true).catch(() => {
                  E(
                    t(
                      "Sign-in could not start. Try again.",
                      "تعذر بدء تسجيل الدخول. حاولي مجددًا.",
                    ),
                  );
                  B(false);
                });
              }}
            >
              {t("Continue with GitHub", "المتابعة باستخدام GitHub")}
            </button>
          </section>
        )}
        {config && auth && (
          <div className="actions">
            <button
              className="secondary"
              disabled={busy}
              onClick={() =>
                window.dispatchEvent(new Event("forme-view-refresh"))
              }
            >
              <RefreshCw size={16} />
              {t("Verify & refresh", "تحقق وتحديث")}
            </button>
            <button
              className="secondary"
              onClick={() => {
                D(null);
                sessionStorage.removeItem(PENDING);
                void clientFor(config)
                  .auth.signOut()
                  .then(() => Auth(false));
              }}
            >
              <LogOut size={16} />
              {t("Sign out", "تسجيل الخروج")}
            </button>
          </div>
        )}
        {busy && (
          <p className="muted">
            {t("Checking permission…", "جارٍ التحقق من الصلاحية…")}
          </p>
        )}
        {data && (
          <>
            <p className="muted">
              {t("Last synced:", "آخر مزامنة:")}{" "}
              {new Date(data.updatedAt).toLocaleString()} ·{" "}
              {t(
                "Updates when the Owner app syncs.",
                "تتحدث البيانات عند مزامنة تطبيق المالكة.",
              )}
            </p>
            {data.charts && (
              <>
                <div className="stat-grid">
                  {[
                    [
                      data.charts.reduce((n, x) => n + x.workouts, 0),
                      t("Workouts · 28 days", "تمارين · ٢٨ يومًا"),
                    ],
                    [
                      data.charts.reduce((n, x) => n + x.minutes, 0),
                      t("Training minutes", "دقائق التدريب"),
                    ],
                    [
                      data.charts.reduce((n, x) => n + x.completedSets, 0),
                      t("Completed sets", "مجموعات مكتملة"),
                    ],
                  ].map(([v, label]) => (
                    <section className="card stat" key={label}>
                      <h2>{v}</h2>
                      <p>{label}</p>
                    </section>
                  ))}
                </div>
                <section className="card chart sharing-chart">
                  <h2>
                    {t(
                      "Consistency, in your own way",
                      "الاستمرارية بطريقتك الخاصة",
                    )}
                  </h2>
                  {data.charts.some((x) => x.workouts > 0) ? (
                    <ResponsiveContainer width="100%" height={220}>
                      <BarChart data={data.charts}>
                        <CartesianGrid vertical={false} stroke="#ffffff0a" />
                        <XAxis
                          dataKey="date"
                          tick={{ fill: "#aaa3ad", fontSize: 10 }}
                          tickFormatter={(v) => String(v).slice(5)}
                          minTickGap={25}
                        />
                        <Tooltip
                          contentStyle={{
                            background: "#222129",
                            border: "1px solid #4a3c45",
                            borderRadius: 12,
                          }}
                        />
                        <Bar
                          dataKey="workouts"
                          name={t("Workouts", "التمارين")}
                          fill="#a97990"
                          radius={[4, 4, 0, 0]}
                        />
                        <Bar
                          dataKey="minutes"
                          name={t("Minutes", "الدقائق")}
                          fill="#8daec7"
                          radius={[4, 4, 0, 0]}
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="empty">
                      <Dumbbell size={25} />
                      <p>
                        {t(
                          "No completed workouts in the shared period.",
                          "لا توجد تمارين مكتملة في الفترة المشاركة.",
                        )}
                      </p>
                    </div>
                  )}
                </section>
              </>
            )}
            {data.schedule && (
              <>
                <div className="section-heading">
                  <h2>{t("Weekly rhythm", "الإيقاع الأسبوعي")}</h2>
                </div>
                <div className="plan-list">
                  {data.schedule.map((p) => (
                    <section className="card plan-card" key={p.day}>
                      <span className="eyebrow">{days[p.day]}</span>
                      <h2>{p.name}</h2>
                      <p>
                        {p.time} · {p.duration}
                      </p>
                      {p.exercises.map((e, i) => (
                        <div className="record" key={i}>
                          <strong>{e.name}</strong>
                          <span>
                            {e.sets} × {e.reps}
                          </span>
                        </div>
                      ))}
                    </section>
                  ))}
                </div>
              </>
            )}
            {data.completed && (
              <>
                <div className="section-heading">
                  <h2>
                    {t(
                      "Showing up, session by session",
                      "الالتزام، جلسة تلو الأخرى",
                    )}
                  </h2>
                </div>
                {data.completed.length ? (
                  data.completed.map((w, i) => (
                    <section className="card viewer-workout" key={i}>
                      <div>
                        <h2>{w.name}</h2>
                        <p>{w.date}</p>
                      </div>
                      <span>
                        {w.minutes} {t("min", "دقيقة")} · {w.completedSets}{" "}
                        {t("sets", "مجموعات")}
                      </span>
                    </section>
                  ))
                ) : (
                  <div className="empty">
                    <Dumbbell size={24} />
                    <p>
                      {t(
                        "No completed sessions shared yet.",
                        "لم تُشارك جلسات مكتملة بعد.",
                      )}
                    </p>
                  </div>
                )}
              </>
            )}
            {!data.schedule && !data.completed && !data.charts && (
              <div className="empty">
                <Eye size={25} />
                <p>
                  {t(
                    "No sections are currently shared.",
                    "لا توجد أقسام مشاركة حاليًا.",
                  )}
                </p>
              </div>
            )}
          </>
        )}
        <footer>
          FORME — {t("Strength in Your Own Way", "القوة بطريقتك الخاصة")}
          <small>
            {t(
              "Authenticated access. No public fitness data.",
              "وصول موثق. بلا بيانات لياقة عامة.",
            )}
          </small>
        </footer>
      </main>
    </div>
  );
}
