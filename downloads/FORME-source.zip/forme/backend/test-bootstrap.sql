-- Synthetic local test auth environment. Never apply this file to Supabase.
create role anon nologin;
create role authenticated nologin;
create schema auth;
create table auth.users(id uuid primary key,raw_user_meta_data jsonb default '{}');
create table auth.identities(user_id uuid references auth.users(id),provider text,provider_id text);
create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;
grant usage on schema auth to authenticated,anon;
grant execute on function auth.uid() to authenticated,anon;

create table auth.sessions(id uuid primary key,user_id uuid references auth.users(id),not_after timestamptz);
create function auth.jwt() returns jsonb language sql stable as $$select jsonb_build_object('sub',auth.uid(),'session_id',coalesce(nullif(current_setting('request.jwt.claim.session_id',true),''),auth.uid()::text))$$;
grant execute on function auth.jwt() to authenticated,anon;
