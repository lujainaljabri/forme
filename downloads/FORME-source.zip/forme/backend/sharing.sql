-- FORME Private Sharing. Apply only to a new, dedicated project AFTER owner approval.
-- No personal history or sample records are contained in this migration.
begin;
create schema if not exists forme_private;
revoke all on schema forme_private from public, anon, authenticated;
create table forme_private.owner (
 singleton boolean primary key default true check(singleton),
 user_id uuid not null unique references auth.users(id) on delete restrict
);
create table forme_private.access (
 singleton boolean primary key default true check(singleton),
 enabled boolean not null default false,
 share_schedule boolean not null default false,
 share_completed boolean not null default false,
 share_charts boolean not null default false,
 target_github_id text,
 viewer_id uuid references auth.users(id) on delete set null,
 invite_hash text,
 invite_expires timestamptz
);
insert into forme_private.access(singleton) values(true);
create table forme_private.summary (
 singleton boolean primary key default true check(singleton),
 schedule jsonb, completed jsonb, charts jsonb,
 updated_at timestamptz not null default now()
);
alter table forme_private.owner enable row level security;
alter table forme_private.access enable row level security;
alter table forme_private.summary enable row level security;
-- No table policies or grants: deny direct access. All access goes through checked RPCs.
revoke all on all tables in schema forme_private from public,anon,authenticated;
alter default privileges in schema forme_private revoke all on tables from public,anon,authenticated;
alter default privileges in schema forme_private revoke execute on functions from public,anon,authenticated;

create function forme_private.require_owner() returns void language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null or not exists(select 1 from forme_private.owner where user_id=auth.uid()) then
  raise exception 'Owner permission required' using errcode='42501';
 end if;
end $$;
revoke all on function forme_private.require_owner() from public,anon,authenticated;

create function public.forme_role() returns text language plpgsql security definer set search_path='' as $$
begin
 perform set_config('response.headers','[{"Cache-Control":"no-store"}]',true);
 if auth.uid() is null then raise exception 'Sign in required' using errcode='42501';end if;
 if exists(select 1 from forme_private.owner where user_id=auth.uid()) then return 'owner';end if;
 if exists(select 1 from forme_private.access where enabled and viewer_id=auth.uid()) then return 'viewer';end if;
 return 'unassigned';
end $$;
create function public.forme_owner_status() returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
 perform forme_private.require_owner();
 perform set_config('response.headers','[{"Cache-Control":"no-store"}]',true);
 select jsonb_build_object('enabled',a.enabled,'schedule',a.share_schedule,'completed',a.share_completed,'charts',a.share_charts,'viewerJoined',a.viewer_id is not null,'targetGithubId',a.target_github_id,'updatedAt',s.updated_at) into result
 from forme_private.access a left join forme_private.summary s using(singleton);
 return result;
end $$;
create function public.forme_configure(p_enabled boolean,p_schedule boolean,p_completed boolean,p_charts boolean) returns void language plpgsql security definer set search_path='' as $$
begin
 perform forme_private.require_owner();
 if p_enabled is null or p_schedule is null or p_completed is null or p_charts is null then raise exception 'Choose explicit permissions';end if;
 if p_enabled and not(p_schedule or p_completed or p_charts) then raise exception 'Choose at least one section';end if;
 -- Lock same row as publish/read/claim/revoke. Scope changes clear stale snapshots atomically.
 perform 1 from forme_private.access for update;
 update forme_private.access set enabled=p_enabled,share_schedule=p_schedule,share_completed=p_completed,share_charts=p_charts;
 delete from forme_private.summary;
end $$;
create function public.forme_invite(p_github_id text,p_token text) returns void language plpgsql security definer set search_path='' as $$
begin
 perform forme_private.require_owner();
 if p_github_id is null or p_github_id !~ '^[0-9]{1,20}$' or p_token is null or p_token !~ '^[a-f0-9]{64}$' then raise exception 'Invalid invitation';end if;
 perform 1 from forme_private.access where enabled for update;
 if not found then raise exception 'Enable sharing first';end if;
 update forme_private.access set target_github_id=p_github_id,viewer_id=null,invite_hash=encode(sha256(convert_to(p_token,'UTF8')),'hex'),invite_expires=now()+interval '24 hours';
end $$;
create function public.forme_claim(p_token text) returns void language plpgsql security definer set search_path='' as $$
declare a forme_private.access%rowtype;
begin
 if auth.uid() is null then raise exception 'Sign in required' using errcode='42501';end if;
 select * into a from forme_private.access for update;
 if p_token is null or p_token !~ '^[a-f0-9]{64}$' or not a.enabled or a.viewer_id is not null or a.invite_expires is null or a.invite_expires<=now() or a.invite_hash is distinct from encode(sha256(convert_to(p_token,'UTF8')),'hex') then raise exception 'Invitation unavailable' using errcode='42501';end if;
 -- Provider identity is verified by Supabase Auth. Never trust user-editable metadata or an email/username supplied by the client.
 if not exists(select 1 from auth.identities where user_id=auth.uid() and provider='github' and provider_id=a.target_github_id) then raise exception 'Invitation unavailable' using errcode='42501';end if;
 if exists(select 1 from forme_private.owner where user_id=auth.uid()) then raise exception 'Owner cannot become Viewer' using errcode='42501';end if;
 update forme_private.access set viewer_id=auth.uid(),invite_hash=null,invite_expires=null;
end $$;

-- Whitelist structure and reconstruct values on the server. Unknown/private keys cause rejection.
create function forme_private.check_keys(v jsonb, allowed text[]) returns void language plpgsql set search_path='' as $$
begin
 if jsonb_typeof(v) is distinct from 'object' then raise exception 'Expected object';end if;
 if exists(select 1 from jsonb_object_keys(v) k where not(k=any(allowed))) or exists(select 1 from unnest(allowed) k where not(v?k)) then raise exception 'Unexpected or missing shared field';end if;
end $$;
create function forme_private.clean_schedule(v jsonb) returns jsonb language plpgsql set search_path='' as $$
declare r jsonb;e jsonb;result jsonb:='[]';exercises jsonb;days integer[]:='{}';
begin
 if v is null then return null;end if;
 if jsonb_typeof(v)<>'array' or jsonb_array_length(v)>7 then raise exception 'Invalid schedule';end if;
 for r in select value from jsonb_array_elements(v) loop
  perform forme_private.check_keys(r,array['day','name','time','duration','exercises']);
  if jsonb_typeof(r->'day')<>'number' or (r->>'day')!~'^[0-6]$' or (r->>'day')::integer=any(days) or jsonb_typeof(r->'name')<>'string' or length(r->>'name')>120 or jsonb_typeof(r->'duration')<>'string' or length(r->>'duration')>40 or jsonb_typeof(r->'time')<>'string' or (r->>'time')!~'^([01][0-9]|2[0-3]):[0-5][0-9]$' or jsonb_typeof(r->'exercises')<>'array' or jsonb_array_length(r->'exercises')>30 then raise exception 'Invalid schedule entry';end if;
  days:=array_append(days,(r->>'day')::integer);exercises:='[]';
  for e in select value from jsonb_array_elements(r->'exercises') loop
   perform forme_private.check_keys(e,array['name','sets','reps']);
   if jsonb_typeof(e->'name')<>'string' or length(e->>'name')>120 or jsonb_typeof(e->'reps')<>'string' or length(e->>'reps')>30 or jsonb_typeof(e->'sets')<>'number' or (e->>'sets')!~'^[0-9]{1,3}$' then raise exception 'Invalid shared exercise';end if;
   exercises:=exercises||jsonb_build_array(jsonb_build_object('name',e->>'name','sets',(e->>'sets')::integer,'reps',e->>'reps'));
  end loop;
  result:=result||jsonb_build_array(jsonb_build_object('day',(r->>'day')::integer,'name',r->>'name','time',r->>'time','duration',r->>'duration','exercises',exercises));
 end loop;return result;
end $$;
create function forme_private.clean_activity(v jsonb,is_chart boolean) returns jsonb language plpgsql set search_path='' as $$
declare r jsonb;result jsonb:='[]';d date;
begin
 if v is null then return null;end if;
 if jsonb_typeof(v)<>'array' or jsonb_array_length(v)>(case when is_chart then 28 else 100 end) then raise exception 'Invalid activity list';end if;
 for r in select value from jsonb_array_elements(v) loop
  perform forme_private.check_keys(r,case when is_chart then array['date','workouts','minutes','completedSets'] else array['date','name','minutes','completedSets'] end);
  if jsonb_typeof(r->'date')<>'string' or (r->>'date')!~'^[0-9]{4}-[0-9]{2}-[0-9]{2}$' then raise exception 'Invalid date';end if;d:=(r->>'date')::date;
  if jsonb_typeof(r->'minutes')<>'number' or (r->>'minutes')!~'^[0-9]{1,7}$' or jsonb_typeof(r->'completedSets')<>'number' or (r->>'completedSets')!~'^[0-9]{1,7}$' then raise exception 'Invalid activity metrics';end if;
  if is_chart then
   if jsonb_typeof(r->'workouts')<>'number' or (r->>'workouts')!~'^[0-9]{1,7}$' then raise exception 'Invalid workout count';end if;
   result:=result||jsonb_build_array(jsonb_build_object('date',to_char(d,'YYYY-MM-DD'),'workouts',(r->>'workouts')::integer,'minutes',(r->>'minutes')::integer,'completedSets',(r->>'completedSets')::integer));
  else
   if jsonb_typeof(r->'name')<>'string' or length(r->>'name')>120 then raise exception 'Invalid workout label';end if;
   result:=result||jsonb_build_array(jsonb_build_object('date',to_char(d,'YYYY-MM-DD'),'name',r->>'name','minutes',(r->>'minutes')::integer,'completedSets',(r->>'completedSets')::integer));
  end if;
 end loop;return result;
end $$;
create function public.forme_publish(p_schedule jsonb,p_completed jsonb,p_charts jsonb) returns void language plpgsql security definer set search_path='' as $$
declare a forme_private.access%rowtype;
begin
 perform forme_private.require_owner();
 select * into a from forme_private.access for update;
 if not a.enabled then raise exception 'Sharing is disabled' using errcode='42501';end if;
 if (not a.share_schedule and p_schedule is not null) or(not a.share_completed and p_completed is not null)or(not a.share_charts and p_charts is not null) then raise exception 'Section is not approved' using errcode='42501';end if;
 insert into forme_private.summary(singleton,schedule,completed,charts) values(true,forme_private.clean_schedule(p_schedule),forme_private.clean_activity(p_completed,false),forme_private.clean_activity(p_charts,true))
 on conflict(singleton) do update set schedule=excluded.schedule,completed=excluded.completed,charts=excluded.charts,updated_at=now();
end $$;
create function public.forme_view() returns jsonb language plpgsql security definer set search_path='' as $$
declare a forme_private.access%rowtype;result jsonb;
begin
 perform set_config('response.headers','[{"Cache-Control":"no-store"}]',true);
 if auth.uid() is null then raise exception 'Sign in required' using errcode='42501';end if;
 select * into a from forme_private.access for share;
 if not a.enabled or a.viewer_id is distinct from auth.uid() then raise exception 'No active Viewer permission' using errcode='42501';end if;
 select jsonb_build_object('schedule',case when a.share_schedule then s.schedule else null end,'completed',case when a.share_completed then s.completed else null end,'charts',case when a.share_charts then s.charts else null end,'updatedAt',s.updated_at) into result from forme_private.summary s;
 return result;
end $$;
create function public.forme_revoke() returns void language plpgsql security definer set search_path='' as $$
begin
 perform forme_private.require_owner();
 update forme_private.access set enabled=false,viewer_id=null,target_github_id=null,invite_hash=null,invite_expires=null;
 delete from forme_private.summary;
end $$;
revoke all on all functions in schema forme_private from public,anon,authenticated;
revoke all on function public.forme_role(),public.forme_owner_status(),public.forme_configure(boolean,boolean,boolean,boolean),public.forme_invite(text,text),public.forme_claim(text),public.forme_publish(jsonb,jsonb,jsonb),public.forme_view(),public.forme_revoke() from public,anon;
grant execute on function public.forme_role(),public.forme_owner_status(),public.forme_configure(boolean,boolean,boolean,boolean),public.forme_invite(text,text),public.forme_claim(text),public.forme_publish(jsonb,jsonb,jsonb),public.forme_view(),public.forme_revoke() to authenticated;
-- No API allows creating or changing the Owner. Bootstrap exactly once with project-admin SQL:
-- insert into forme_private.owner(singleton,user_id) values(true,'YOUR-VERIFIED-AUTH-USER-UUID');
commit;
